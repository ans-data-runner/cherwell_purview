/* ============================================================================
 Fixflo Silver Lakehouse -> Gold Fabric Warehouse loaders
 Replace YOUR_SILVER_LAKEHOUSE_NAME globally before running this script.
 Source and Warehouse must be queryable in the same active Fabric workspace for
 three-part SQL naming.
 ============================================================================ */

CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_date
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_date;
    INSERT INTO fixflo.dim_date
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_date];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_estate
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_estate;
    INSERT INTO fixflo.dim_estate
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_estate];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_block
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_block;
    INSERT INTO fixflo.dim_block
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_block];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_property
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_property;
    INSERT INTO fixflo.dim_property
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_property];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_landlord
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_landlord;
    INSERT INTO fixflo.dim_landlord
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_landlord];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_tenant
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_tenant;
    INSERT INTO fixflo.dim_tenant
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_tenant];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_leaseholder
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_leaseholder;
    INSERT INTO fixflo.dim_leaseholder
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_leaseholder];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_contractor
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_contractor;
    INSERT INTO fixflo.dim_contractor
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_contractor];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_agent
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_agent;
    INSERT INTO fixflo.dim_agent
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_agent];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_agency
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_agency;
    INSERT INTO fixflo.dim_agency
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_agency];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_fault
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_fault;
    INSERT INTO fixflo.dim_fault
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_fault];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_issue_status
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_issue_status;
    INSERT INTO fixflo.dim_issue_status
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_issue_status];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_issue_type
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_issue_type;
    INSERT INTO fixflo.dim_issue_type
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_issue_type];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_dim_issue_priority
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.dim_issue_priority;
    INSERT INTO fixflo.dim_issue_priority
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[dim_issue_priority];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_fact_repair
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.fact_repair;
    INSERT INTO fixflo.fact_repair
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[fact_repair];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_fact_job
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.fact_job;
    INSERT INTO fixflo.fact_job
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[fact_job];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_fact_invoice
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.fact_invoice;
    INSERT INTO fixflo.fact_invoice
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[fact_invoice];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_fact_quote
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.fact_quote;
    INSERT INTO fixflo.fact_quote
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[fact_quote];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_fact_appointment
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.fact_appointment;
    INSERT INTO fixflo.fact_appointment
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[fact_appointment];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_fact_repair_snapshot
AS
BEGIN
    SET NOCOUNT ON;
    TRUNCATE TABLE fixflo.fact_repair_snapshot;
    INSERT INTO fixflo.fact_repair_snapshot
    SELECT *
    FROM [YOUR_SILVER_LAKEHOUSE_NAME].[fixflo].[fact_repair_snapshot];
END;
GO


CREATE OR ALTER PROCEDURE fixflo.usp_load_all
AS
BEGIN
    SET NOCOUNT ON;
    -- Dimensions first, facts second. Full-refresh starter pattern.
    EXEC fixflo.usp_load_dim_date;
    EXEC fixflo.usp_load_dim_estate;
    EXEC fixflo.usp_load_dim_block;
    EXEC fixflo.usp_load_dim_property;
    EXEC fixflo.usp_load_dim_landlord;
    EXEC fixflo.usp_load_dim_tenant;
    EXEC fixflo.usp_load_dim_leaseholder;
    EXEC fixflo.usp_load_dim_contractor;
    EXEC fixflo.usp_load_dim_agent;
    EXEC fixflo.usp_load_dim_agency;
    EXEC fixflo.usp_load_dim_fault;
    EXEC fixflo.usp_load_dim_issue_status;
    EXEC fixflo.usp_load_dim_issue_type;
    EXEC fixflo.usp_load_dim_issue_priority;
    EXEC fixflo.usp_load_fact_repair;
    EXEC fixflo.usp_load_fact_job;
    EXEC fixflo.usp_load_fact_invoice;
    EXEC fixflo.usp_load_fact_quote;
    EXEC fixflo.usp_load_fact_appointment;
    EXEC fixflo.usp_load_fact_repair_snapshot;
END;
GO
