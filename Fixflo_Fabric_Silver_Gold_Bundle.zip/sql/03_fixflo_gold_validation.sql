/* Fixflo Gold validation after EXEC fixflo.usp_load_all; */
SELECT 'dim_date' table_name, COUNT_BIG(*) row_count FROM fixflo.dim_date UNION ALL
SELECT 'dim_estate', COUNT_BIG(*) FROM fixflo.dim_estate UNION ALL
SELECT 'dim_block', COUNT_BIG(*) FROM fixflo.dim_block UNION ALL
SELECT 'dim_property', COUNT_BIG(*) FROM fixflo.dim_property UNION ALL
SELECT 'dim_landlord', COUNT_BIG(*) FROM fixflo.dim_landlord UNION ALL
SELECT 'dim_tenant', COUNT_BIG(*) FROM fixflo.dim_tenant UNION ALL
SELECT 'dim_leaseholder', COUNT_BIG(*) FROM fixflo.dim_leaseholder UNION ALL
SELECT 'dim_contractor', COUNT_BIG(*) FROM fixflo.dim_contractor UNION ALL
SELECT 'dim_agent', COUNT_BIG(*) FROM fixflo.dim_agent UNION ALL
SELECT 'dim_agency', COUNT_BIG(*) FROM fixflo.dim_agency UNION ALL
SELECT 'dim_fault', COUNT_BIG(*) FROM fixflo.dim_fault UNION ALL
SELECT 'dim_issue_status', COUNT_BIG(*) FROM fixflo.dim_issue_status UNION ALL
SELECT 'dim_issue_type', COUNT_BIG(*) FROM fixflo.dim_issue_type UNION ALL
SELECT 'dim_issue_priority', COUNT_BIG(*) FROM fixflo.dim_issue_priority UNION ALL
SELECT 'fact_repair', COUNT_BIG(*) FROM fixflo.fact_repair UNION ALL
SELECT 'fact_job', COUNT_BIG(*) FROM fixflo.fact_job UNION ALL
SELECT 'fact_invoice', COUNT_BIG(*) FROM fixflo.fact_invoice UNION ALL
SELECT 'fact_quote', COUNT_BIG(*) FROM fixflo.fact_quote UNION ALL
SELECT 'fact_appointment', COUNT_BIG(*) FROM fixflo.fact_appointment UNION ALL
SELECT 'fact_repair_snapshot', COUNT_BIG(*) FROM fixflo.fact_repair_snapshot;

-- Key relationship spot checks
SELECT COUNT_BIG(*) AS repair_property_orphans
FROM fixflo.fact_repair f
LEFT JOIN fixflo.dim_property d ON d.property_key = f.property_key
WHERE f.property_key <> 0 AND d.property_key IS NULL;

SELECT COUNT_BIG(*) AS job_contractor_orphans
FROM fixflo.fact_job f
LEFT JOIN fixflo.dim_contractor d ON d.contractor_key = f.contractor_key
WHERE f.contractor_key <> 0 AND d.contractor_key IS NULL;

SELECT COUNT_BIG(*) AS invoice_job_orphans
FROM fixflo.fact_invoice f
LEFT JOIN fixflo.fact_job j ON j.job_key = f.job_key
WHERE f.job_key <> 0 AND j.job_key IS NULL;
