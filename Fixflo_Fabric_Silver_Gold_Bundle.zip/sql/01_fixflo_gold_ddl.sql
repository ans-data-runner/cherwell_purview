/* ============================================================================
   Fixflo Gold Warehouse - physical dimensional model
   Run once in the Fabric Warehouse.
   ============================================================================ */

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'fixflo')
    EXEC('CREATE SCHEMA fixflo');
GO

CREATE TABLE fixflo.dim_date (
    date_key int NOT NULL, full_date date NOT NULL, calendar_year int NULL, month_number int NULL, day_number int NULL,
    month_name_short varchar(10) NULL, month_name_long varchar(20) NULL, month_start_date date NULL, month_end_date date NULL,
    month_offset int NULL, previous_month_start_date date NULL, previous_month_end_date date NULL, quarter_number int NULL,
    quarter_name varchar(10) NULL, year_quarter varchar(20) NULL, day_name_short varchar(10) NULL, day_name_long varchar(20) NULL,
    day_of_year int NULL, week_of_year int NULL, iso_week int NULL, is_weekend bit NULL, fiscal_year int NULL,
    fiscal_year_name varchar(20) NULL, fiscal_period int NULL, financial_period_name varchar(20) NULL, fiscal_quarter_number int NULL,
    fiscal_quarter varchar(10) NULL, fiscal_year_quarter varchar(20) NULL, fiscal_year_start_date date NULL, fiscal_year_end_date date NULL
);
GO
CREATE TABLE fixflo.dim_estate (
    estate_key bigint NOT NULL, estate_id bigint NULL, external_estate_ref varchar(255) NULL, estate_name varchar(500) NULL, brand varchar(255) NULL,
    assigned_agent_key bigint NULL, assigned_agent_id varchar(255) NULL, is_deleted bit NULL, update_ts datetime2 NULL, source_ingest_ts datetime2 NULL
);
GO
CREATE TABLE fixflo.dim_block (
    block_key bigint NOT NULL, block_id bigint NULL, estate_key bigint NULL, estate_id bigint NULL, landlord_key bigint NULL, landlord_id varchar(255) NULL,
    external_block_reference varchar(255) NULL, external_estate_ref varchar(255) NULL, external_landlord_ref varchar(255) NULL, block_name varchar(500) NULL,
    brand varchar(255) NULL, address_line_1 varchar(1000) NULL, address_line_2 varchar(1000) NULL, town varchar(255) NULL, county varchar(255) NULL,
    postcode varchar(50) NULL, country varchar(100) NULL, assigned_agent_name varchar(500) NULL, property_manager_name varchar(500) NULL,
    management_start_date date NULL, management_end_date date NULL, is_standalone bit NULL, is_deleted bit NULL, created_ts datetime2 NULL,
    update_ts datetime2 NULL, source_ingest_ts datetime2 NULL
);
GO
CREATE TABLE fixflo.dim_property (
    property_key bigint NOT NULL, property_id bigint NULL, external_property_ref varchar(255) NULL, block_key bigint NULL, block_id bigint NULL,
    brand_id varchar(255) NULL, brand_name varchar(255) NULL, archive_status varchar(255) NULL, address_line_1 varchar(1000) NULL,
    address_line_2 varchar(1000) NULL, town varchar(255) NULL, county varchar(255) NULL, postcode varchar(50) NULL, country varchar(100) NULL,
    assigned_agent_name varchar(500) NULL, assigned_team varchar(500) NULL, property_manager_name varchar(500) NULL,
    is_not_managed bit NULL, is_deleted bit NULL, created_ts datetime2 NULL, update_ts datetime2 NULL, source_ingest_ts datetime2 NULL
);
GO
CREATE TABLE fixflo.dim_landlord (
    landlord_key bigint NOT NULL, landlord_id varchar(255) NULL, external_ref varchar(255) NULL, display_name varchar(500) NULL,
    company_name varchar(500) NULL, first_name varchar(255) NULL, surname varchar(255) NULL, title varchar(100) NULL, brand varchar(255) NULL,
    address_line_1 varchar(1000) NULL, address_line_2 varchar(1000) NULL, town varchar(255) NULL, county varchar(255) NULL, postcode varchar(50) NULL,
    country varchar(100) NULL, works_authorisation_limit decimal(18,2) NULL, is_deleted bit NULL, update_ts datetime2 NULL, source_ingest_ts datetime2 NULL
);
GO
CREATE TABLE fixflo.dim_tenant (
    tenant_key bigint NOT NULL, tenant_id varchar(255) NULL, external_ref varchar(255) NULL, external_property_ref varchar(255) NULL, property_key bigint NULL,
    display_name varchar(500) NULL, company_name varchar(500) NULL, first_name varchar(255) NULL, surname varchar(255) NULL, title varchar(100) NULL,
    brand_id varchar(255) NULL, brand_name varchar(255) NULL, address_line_1 varchar(1000) NULL, address_line_2 varchar(1000) NULL,
    town varchar(255) NULL, county varchar(255) NULL, postcode varchar(50) NULL, country varchar(100) NULL, is_anonymised bit NULL,
    is_deleted bit NULL, update_ts datetime2 NULL, source_ingest_ts datetime2 NULL
);
GO
CREATE TABLE fixflo.dim_leaseholder (
    leaseholder_key bigint NOT NULL, leaseholder_id varchar(255) NULL, external_leaseholder_ref varchar(255) NULL, auth_user_id bigint NULL,
    display_name varchar(500) NULL, company_name varchar(500) NULL, first_name varchar(255) NULL, surname varchar(255) NULL, title varchar(100) NULL,
    brand_id varchar(255) NULL, brand_name varchar(255) NULL, address_line_1 varchar(1000) NULL, address_line_2 varchar(1000) NULL,
    town varchar(255) NULL, county varchar(255) NULL, postcode varchar(50) NULL, country varchar(100) NULL, is_deleted bit NULL,
    update_ts datetime2 NULL, source_ingest_ts datetime2 NULL
);
GO
CREATE TABLE fixflo.dim_contractor (
    contractor_key bigint NOT NULL, contractor_id varchar(255) NULL, external_ref varchar(255) NULL, company_name varchar(500) NULL,
    display_name varchar(500) NULL, first_name varchar(255) NULL, surname varchar(255) NULL, title varchar(100) NULL, brand varchar(255) NULL,
    services varchar(4000) NULL, certifications varchar(4000) NULL, address_line_1 varchar(1000) NULL, address_line_2 varchar(1000) NULL,
    town varchar(255) NULL, county varchar(255) NULL, postcode varchar(50) NULL, country varchar(100) NULL, invoice_company_number varchar(255) NULL,
    default_due_days bigint NULL, default_tax_rate decimal(18,4) NULL, invoice_terms varchar(1000) NULL, vat_number varchar(255) NULL,
    is_deleted bit NULL, update_ts datetime2 NULL, source_ingest_ts datetime2 NULL
);
GO
CREATE TABLE fixflo.dim_agent (
    agent_key bigint NOT NULL, agent_business_id varchar(500) NULL, agent_id varchar(255) NULL, external_ref varchar(255) NULL,
    display_name varchar(500) NULL, email_address varchar(500) NULL, contact_no varchar(255) NULL, brand varchar(255) NULL,
    is_deleted bit NULL, update_ts datetime2 NULL, source_roles varchar(1000) NULL
);
GO
CREATE TABLE fixflo.dim_agency (agency_key bigint NOT NULL, agency_id varchar(255) NULL, agency_name varchar(500) NULL);
GO
CREATE TABLE fixflo.dim_fault (
    fault_key bigint NOT NULL, fault_id bigint NULL, fault_parent_0_id bigint NULL, fault_parent_1_id bigint NULL, fault_parent_2_id bigint NULL,
    fault_category varchar(1000) NULL, fault_title varchar(1000) NULL
);
GO
CREATE TABLE fixflo.dim_issue_status (status_key bigint NOT NULL, status varchar(500) NULL);
GO
CREATE TABLE fixflo.dim_issue_type (issue_type_key bigint NOT NULL, issue_type varchar(500) NULL);
GO
CREATE TABLE fixflo.dim_issue_priority (priority_key bigint NOT NULL, fault_priority bigint NULL);
GO

CREATE TABLE fixflo.fact_repair (
    repair_key bigint NOT NULL, issue_id varchar(255) NULL, property_key bigint NULL, block_key bigint NULL, estate_key bigint NULL, landlord_key bigint NULL,
    tenant_key bigint NULL, agency_key bigint NULL, assigned_agent_key bigint NULL, raised_by_agent_key bigint NULL, fault_key bigint NULL,
    status_key bigint NULL, issue_type_key bigint NULL, priority_key bigint NULL, created_date_key int NULL, created_ts datetime2 NULL,
    status_changed_date_key int NULL, status_changed_ts datetime2 NULL, attendance_date_key int NULL, attendance_ts datetime2 NULL,
    quote_end_date_key int NULL, quote_end_ts datetime2 NULL, external_ref varchar(255) NULL, external_tenancy_agreement_ref varchar(255) NULL,
    external_tenant_ref varchar(255) NULL, close_reason varchar(1000) NULL, close_reason_description varchar(4000) NULL, reporter_role varchar(255) NULL,
    cost_code varchar(255) NULL, works_paid_by varchar(255) NULL, additional_details varchar(8000) NULL, fault_notes varchar(8000) NULL, tenant_notes varchar(8000) NULL,
    is_communal bit NULL, is_emergency bit NULL, is_planned_maintenance bit NULL, vulnerable_occupiers bit NULL, tenant_presence_requested bit NULL,
    terms_accepted bit NULL, works_authorisation_limit decimal(18,2) NULL, repair_count int NOT NULL, source_ingest_ts datetime2 NULL
);
GO
CREATE TABLE fixflo.fact_job (
    job_key bigint NOT NULL, job_id varchar(255) NULL, repair_key bigint NULL, issue_id varchar(255) NULL, contractor_key bigint NULL, property_key bigint NULL,
    block_key bigint NULL, estate_key bigint NULL, landlord_key bigint NULL, tenant_key bigint NULL, job_created_date_key int NULL, job_created_ts datetime2 NULL,
    job_start_date_key int NULL, job_start_ts datetime2 NULL, tenant_accepted_date_key int NULL, tenant_accepted_ts datetime2 NULL,
    job_completed_date_key int NULL, job_completed_ts datetime2 NULL, works_expiry_date_key int NULL, works_expiry_ts datetime2 NULL,
    job_update_date_key int NULL, job_update_ts datetime2 NULL, external_job_ref varchar(255) NULL, contractor_network_job_ref varchar(255) NULL,
    contractor_network varchar(1000) NULL, is_active bit NULL, job_duration_raw varchar(255) NULL, job_completed_raw varchar(255) NULL,
    landlord_approval varchar(1000) NULL, external_user_approval varchar(1000) NULL, jobber_agreed_with_tenant_start_date bit NULL,
    jobber_notes varchar(8000) NULL, tenant_notes varchar(8000) NULL, job_count int NOT NULL, source_ingest_ts datetime2 NULL
);
GO
CREATE TABLE fixflo.fact_invoice (
    invoice_key bigint NOT NULL, invoice_number varchar(255) NULL, job_key bigint NULL, job_id varchar(255) NULL, repair_key bigint NULL, issue_id varchar(255) NULL,
    contractor_key bigint NULL, property_key bigint NULL, block_key bigint NULL, estate_key bigint NULL, landlord_key bigint NULL,
    invoice_date_key int NULL, invoice_ts datetime2 NULL, invoice_due_date_key int NULL, invoice_due_ts datetime2 NULL,
    invoice_method varchar(255) NULL, invoice_comments varchar(8000) NULL, payable_net decimal(18,2) NULL, payable_tax decimal(18,2) NULL,
    payable_gross decimal(18,2) NULL, receivable_net decimal(18,2) NULL, receivable_tax decimal(18,2) NULL, receivable_gross decimal(18,2) NULL,
    quoted_payable_net decimal(18,2) NULL, quoted_payable_tax decimal(18,2) NULL, quoted_payable_gross decimal(18,2) NULL,
    quoted_receivable_net decimal(18,2) NULL, quoted_receivable_tax decimal(18,2) NULL, quoted_receivable_gross decimal(18,2) NULL,
    payable_variance_gross decimal(18,2) NULL, receivable_variance_gross decimal(18,2) NULL, gross_margin_value decimal(18,2) NULL,
    invoice_count int NOT NULL, source_ingest_ts datetime2 NULL
);
GO
CREATE TABLE fixflo.fact_quote (
    quote_key bigint NOT NULL, repair_key bigint NULL, issue_id varchar(255) NULL, job_key bigint NULL, job_id varchar(255) NULL,
    contractor_key bigint NULL, property_key bigint NULL, block_key bigint NULL, estate_key bigint NULL, quote_ordinal int NULL,
    quote_record_id varchar(255) NULL, quote_source varchar(100) NULL, quote_status varchar(255) NULL, quote_end_date_key int NULL, quote_end_ts datetime2 NULL,
    quote_notes varchar(8000) NULL, payload_amount decimal(18,2) NULL, quoted_payable_net decimal(18,2) NULL, quoted_payable_tax decimal(18,2) NULL,
    quoted_payable_gross decimal(18,2) NULL, quoted_receivable_net decimal(18,2) NULL, quoted_receivable_tax decimal(18,2) NULL,
    quoted_receivable_gross decimal(18,2) NULL, quote_payload_json varchar(8000) NULL, payload_parse_mode varchar(100) NULL,
    quote_count int NOT NULL, source_ingest_ts datetime2 NULL
);
GO
CREATE TABLE fixflo.fact_appointment (
    appointment_key bigint NOT NULL, repair_key bigint NULL, issue_id varchar(255) NULL, job_key bigint NULL, job_id varchar(255) NULL,
    contractor_key bigint NULL, property_key bigint NULL, block_key bigint NULL, estate_key bigint NULL, appointment_ordinal int NULL,
    appointment_id varchar(255) NULL, appointment_status varchar(255) NULL, appointment_start_date_key int NULL, appointment_start_ts datetime2 NULL,
    appointment_end_date_key int NULL, appointment_end_ts datetime2 NULL, appointment_description varchar(4000) NULL, appointment_range varchar(1000) NULL,
    appointment_payload_json varchar(8000) NULL, payload_parse_mode varchar(100) NULL, appointment_count int NOT NULL, source_ingest_ts datetime2 NULL
);
GO
CREATE TABLE fixflo.fact_repair_snapshot (
    snapshot_key bigint NOT NULL, snapshot_date_key int NOT NULL, snapshot_date date NOT NULL, snapshot_ts datetime2 NULL,
    repair_key bigint NULL, issue_id varchar(255) NULL, property_key bigint NULL, block_key bigint NULL, estate_key bigint NULL,
    landlord_key bigint NULL, tenant_key bigint NULL, agency_key bigint NULL, status_key bigint NULL, issue_type_key bigint NULL,
    priority_key bigint NULL, created_date_key int NULL, status_changed_date_key int NULL, repair_count int NOT NULL, source_ingest_ts datetime2 NULL
);
GO

/* Optional metadata constraints for semantic-model relationship discovery. Fabric Warehouse constraints are NOT ENFORCED. */
ALTER TABLE fixflo.dim_date ADD CONSTRAINT PK_fixflo_dim_date PRIMARY KEY NONCLUSTERED (date_key) NOT ENFORCED;
ALTER TABLE fixflo.dim_estate ADD CONSTRAINT PK_fixflo_dim_estate PRIMARY KEY NONCLUSTERED (estate_key) NOT ENFORCED;
ALTER TABLE fixflo.dim_block ADD CONSTRAINT PK_fixflo_dim_block PRIMARY KEY NONCLUSTERED (block_key) NOT ENFORCED;
ALTER TABLE fixflo.dim_property ADD CONSTRAINT PK_fixflo_dim_property PRIMARY KEY NONCLUSTERED (property_key) NOT ENFORCED;
ALTER TABLE fixflo.dim_landlord ADD CONSTRAINT PK_fixflo_dim_landlord PRIMARY KEY NONCLUSTERED (landlord_key) NOT ENFORCED;
ALTER TABLE fixflo.dim_tenant ADD CONSTRAINT PK_fixflo_dim_tenant PRIMARY KEY NONCLUSTERED (tenant_key) NOT ENFORCED;
ALTER TABLE fixflo.dim_leaseholder ADD CONSTRAINT PK_fixflo_dim_leaseholder PRIMARY KEY NONCLUSTERED (leaseholder_key) NOT ENFORCED;
ALTER TABLE fixflo.dim_contractor ADD CONSTRAINT PK_fixflo_dim_contractor PRIMARY KEY NONCLUSTERED (contractor_key) NOT ENFORCED;
ALTER TABLE fixflo.dim_agent ADD CONSTRAINT PK_fixflo_dim_agent PRIMARY KEY NONCLUSTERED (agent_key) NOT ENFORCED;
ALTER TABLE fixflo.dim_agency ADD CONSTRAINT PK_fixflo_dim_agency PRIMARY KEY NONCLUSTERED (agency_key) NOT ENFORCED;
ALTER TABLE fixflo.dim_fault ADD CONSTRAINT PK_fixflo_dim_fault PRIMARY KEY NONCLUSTERED (fault_key) NOT ENFORCED;
ALTER TABLE fixflo.dim_issue_status ADD CONSTRAINT PK_fixflo_dim_issue_status PRIMARY KEY NONCLUSTERED (status_key) NOT ENFORCED;
ALTER TABLE fixflo.dim_issue_type ADD CONSTRAINT PK_fixflo_dim_issue_type PRIMARY KEY NONCLUSTERED (issue_type_key) NOT ENFORCED;
ALTER TABLE fixflo.dim_issue_priority ADD CONSTRAINT PK_fixflo_dim_issue_priority PRIMARY KEY NONCLUSTERED (priority_key) NOT ENFORCED;
GO
