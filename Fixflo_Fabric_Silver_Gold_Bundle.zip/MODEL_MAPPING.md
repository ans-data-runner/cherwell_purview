# Fixflo Silver / Gold model mapping

## Dimensions

| Table | Grain | Primary Bronze source | Key logic |
|---|---|---|---|
| dim_date | One row per date | Recreated from logic in DIM_DATE_VW | YYYYMMDD date_key; April fiscal year |
| dim_estate | One Estate.Id | FixFlo.Estate | deterministic BIGINT from Estate.Id |
| dim_block | One Block.Id | FixFlo.Block | deterministic BIGINT from Block.Id |
| dim_property | One Property.Id | FixFlo.Property | deterministic BIGINT from Property.Id |
| dim_landlord | One Landlord.Id | FixFlo.Landlord | deterministic BIGINT from Landlord.Id |
| dim_tenant | One Tenant.Id | FixFlo.Tenant | deterministic BIGINT from Tenant.Id; property resolved by ExternalPropertyRef |
| dim_leaseholder | One Leaseholder.Id | FixFlo.Leaseholder | intentionally standalone until a property/block relationship is confirmed |
| dim_contractor | One Contractor.Id | FixFlo.Contractor | deterministic BIGINT from Contractor.Id; bank details excluded |
| dim_agent | One conformed agent | Embedded agent records in Issue and Estate | Id, then ExternalRef/email/display name fallback |
| dim_agency | One AgencyId/AgencyName | FixFlo.Issue | AgencyId, with AgencyName fallback |
| dim_fault | One fault hierarchy combination | FixFlo.Issue FaultTree/FaultCategory/FaultTitle | composite deterministic key |
| dim_issue_status | One distinct Status | FixFlo.Issue | deterministic key from Status |
| dim_issue_type | One distinct IssueType | FixFlo.Issue | deterministic key from IssueType |
| dim_issue_priority | One distinct FaultPriority | FixFlo.Issue | deterministic key from FaultPriority |

## Facts

| Table | Grain | Bronze source | Purpose |
|---|---|---|---|
| fact_repair | One current Issue.Id | FixFlo.Issue | Repair/service request lifecycle and current operational state |
| fact_job | One Job_Id | FixFlo.Issue Job_* | Contractor work/job execution |
| fact_invoice | One Job_Id + invoice number (or one job summary when number missing) | FixFlo.Issue Job_Invoice* + Job_Price* | Payable/receivable, VAT, billed-vs-quoted, gross margin |
| fact_quote | One parsed Quotes payload record, with Job quoted-value fallback | FixFlo.Issue Quotes + Job_QuotedPrice* | Quote analysis while preserving source payload |
| fact_appointment | One parsed Job_Appointments payload record, with summary fallback | FixFlo.Issue Job_Appointments | Appointment analysis while preserving source payload |
| fact_repair_snapshot | One Issue.Id per ingestion date | Historical rows of FixFlo.Issue | Daily status/backlog snapshot if Bronze retains history |

## Relationship backbone

Estate -> Block -> Property

Block also carries Landlord. Tenant resolves to Property through ExternalPropertyRef. Facts carry direct dimension keys to keep the Power BI model star-shaped rather than requiring dimension-to-dimension traversal.

## Items deliberately left for customer data review

- `Quotes`, `QuoteRequests`, `Job_Appointments`, and `InactiveJobs` are varchar payloads in the supplied schema. Their exact nested structure cannot be known until real values are inspected.
- `fact_quote` and `fact_appointment` therefore preserve raw payload JSON and expose parse mode so mappings can be refined safely.
- `QuoteRequests` and `InactiveJobs` are profiled in `audit_quality`; if either proves analytically important and multi-valued, add `fact_quote_request` or `fact_inactive_job` as a later fact.
- The supplied schema exposes no clear Leaseholder-to-Property relationship.
