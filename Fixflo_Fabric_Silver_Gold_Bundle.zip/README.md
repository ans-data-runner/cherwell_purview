# Fixflo Microsoft Fabric Bronze → Silver → Gold bundle

## Model included

### Silver dimensions
- dim_date
- dim_estate
- dim_block
- dim_property
- dim_landlord
- dim_tenant
- dim_leaseholder
- dim_contractor
- dim_agent
- dim_agency
- dim_fault
- dim_issue_status
- dim_issue_type
- dim_issue_priority

### Silver facts
1. fact_repair — one current row per Issue.Id
2. fact_job — one row per Job_Id
3. fact_invoice — one invoice summary per Job_Id + invoice number (derived from Issue.Job_* fields)
4. fact_quote — one generic quote payload record, with fallback to Job quoted amounts
5. fact_appointment — one generic appointment payload record
6. fact_repair_snapshot — one Issue.Id per Bronze ingestion day

## Important source limitations
- The supplied Bronze schema has no standalone Invoice table. `fact_invoice` is therefore a derived fact from the Job_* invoice/financial attributes embedded in FixFlo.Issue.
- `Quotes`, `QuoteRequests`, `Job_Appointments`, and `InactiveJobs` are only exposed as varchar(8000) in the supplied schema. The quote and appointment notebooks preserve their raw payload and apply a deliberately generic JSON parser. Review actual customer values and refine the typed extraction afterwards.
- Leaseholder has no reliable Property/Block key in the supplied schema, so dim_leaseholder is intentionally standalone.
- fact_repair_snapshot only provides true history when Bronze retains repeated Issue versions across ingestion days.

## Fabric setup
1. Import all .ipynb files into the Fabric workspace.
2. Attach the Silver lakehouse to every notebook and make it the DEFAULT lakehouse.
3. Open `00_fixflo_common` and replace:
   - `YOUR_WORKSPACE_NAME`
   - `YOUR_BRONZE_LAKEHOUSE_NAME`
4. Bronze is referenced using Fabric's four-part Spark namespace: `workspace.lakehouse.schema.table`.
5. Run `99_run_all_fixflo_silver`.
6. Review `fixflo.audit_quality`, especially payload parse modes and history counts.
7. In the Gold Warehouse, run `sql/01_fixflo_gold_ddl.sql` once.
8. Replace every `YOUR_SILVER_LAKEHOUSE_NAME` placeholder in `sql/02_fixflo_gold_load_procedures.sql` with the Silver lakehouse item name, then run the script.
9. Execute `EXEC fixflo.usp_load_all;` after each successful Silver build.

## Loading strategy
The supplied Gold procedures use TRUNCATE + INSERT for a simple, deterministic initial implementation. This is deliberate for the first customer review. Once row volumes, source retention and change patterns are understood, the dimensions/facts can be converted to incremental MERGE-style processing where appropriate.

## Privacy / governance
The curated Contractor table deliberately omits contractor bank account number and sort code. Tenant/Landlord dimensions contain identity data but omit email/telephone fields in the Gold DDL supplied here. Adjust to the customer's governance requirements before production reporting.
