#!/usr/bin/env python
# coding: utf-8

# ## nb_supfam_dataset_curation_v5
#
# Builds the Supporting Families CDM tables in lh_data_platform_silver.cdm
# from lh_data_platform_bronze (child_social / education schemas).
#
# Before running:
#   - Attach BOTH lakehouses to the notebook; set lh_data_platform_silver as default.
#   - All reads/writes use fully-qualified lakehouse.schema.table names, so every
#     output lands in silver regardless of which lakehouse is default.
#   - Cells are in dependency order: run top to bottom (Run all).

# In[1]:


# ============================================================
# STAGE 0 — Setup: imports, Spark config, load helper, schemas
# ============================================================

from delta.tables import DeltaTable
from pyspark.sql.types import StructType, StructField, StringType

spark.conf.set("spark.sql.legacy.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.legacy.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

BUILT_TABLES = []


def OverwriteLoad(df, targetTable: str, partitionByCols: list = None, zOrderByCols: list = None):
    """Overwrite a Delta table (fully-qualified name) and optionally Z-order it."""
    (
        df.write
          .format("delta")
          .mode("overwrite")
          .option("overwriteSchema", "true")
          .partitionBy(*(partitionByCols or []))
          .saveAsTable(targetTable)
    )

    if zOrderByCols:
        DeltaTable.forName(spark, targetTable).optimize().executeZOrderBy(*zOrderByCols)

    BUILT_TABLES.append(targetTable)
    print(f"built: {targetTable}")


# In[2]:


spark.sql("CREATE SCHEMA IF NOT EXISTS lh_data_platform_silver.cdm")
spark.sql("CREATE SCHEMA IF NOT EXISTS lh_data_platform_silver.cdm_ext")


# In[3]:


# ============================================================
# STAGE 1 — Base tables (bronze sources only, no cdm dependencies)
# ============================================================

# cdm.school
df = spark.sql("""
    SELECT
        dim_sc_school_id AS SchoolId
    FROM lh_data_platform_bronze.education.dim_sc_school
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.school")


# In[4]:


# cdm.mfh_episode
df = spark.sql("""
    SELECT
        dp.LEGACY_ID AS PersonID,
        fmp.FACT_MISSING_PERSON_ID AS MfHEpisodeID,
        fmp.START_DTTM AS MfHStartDate,
        fmp.END_DTTM AS MfHEndDate
    FROM lh_data_platform_bronze.child_social.dim_person dp
    INNER JOIN lh_data_platform_bronze.child_social.fact_missing_person fmp
        ON dp.dim_person_id = fmp.dim_person_id
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.mfh_episode")


# In[5]:


# cdm.cin_episode
df = spark.sql("""
    SELECT DISTINCT
        dp.LEGACY_ID AS PersonID,
        fcps.FACT_CARE_PLAN_SUMMARY_ID AS CINEpisodeID,
        TO_DATE(fcps.START_DTTM, 'yyyy-MM-dd HH:mm:ss') AS CINStartDate,
        TO_DATE(fcps.END_DTTM, 'yyyy-MM-dd HH:mm:ss') AS CINEndDate,
        CASE
            WHEN fr.group_referral_id IS NULL THEN
                concat_ws('', 'CIN', CAST(fr.dim_person_id AS STRING),
                          date_format(to_timestamp(fcps.START_DTTM, 'yyyy-MM-dd HH:mm:ss'), 'yyyyMMdd'))
            ELSE
                concat_ws('', 'CIN', CAST(fr.group_referral_id AS STRING),
                          date_format(to_timestamp(fcps.START_DTTM, 'yyyy-MM-dd HH:mm:ss'), 'yyyyMMdd'))
        END AS GroupID
    FROM lh_data_platform_bronze.child_social.dim_person AS dp
    JOIN lh_data_platform_bronze.child_social.fact_care_plan_summary AS fcps
        ON dp.dim_person_id = fcps.dim_person_id
    JOIN lh_data_platform_bronze.child_social.fact_referrals AS fr
        ON dp.dim_person_id = fr.dim_person_id
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.cin_episode")


# In[6]:


# cdm.cla_episode
df = spark.sql("""
    SELECT DISTINCT
        dp.LEGACY_ID AS PersonID,
        fcl.FACT_CLA_ID AS CLAEpisodeID,
        TO_DATE(fcl.START_DTTM, 'yyyy-MM-dd HH:mm:ss') AS CLAStartDate,
        TO_DATE(fcl.END_DTTM, 'yyyy-MM-dd HH:mm:ss') AS CLAEndDate,
        CASE
            WHEN fr.group_referral_id IS NULL THEN
                concat_ws('', 'CLA', CAST(fr.dim_person_id AS STRING),
                          date_format(to_timestamp(fcl.START_DTTM, 'yyyy-MM-dd HH:mm:ss'), 'yyyyMMdd'))
            ELSE
                concat_ws('', 'CLA', CAST(fr.group_referral_id AS STRING),
                          date_format(to_timestamp(fcl.START_DTTM, 'yyyy-MM-dd HH:mm:ss'), 'yyyyMMdd'))
        END AS GroupID
    FROM lh_data_platform_bronze.child_social.dim_person AS dp
    JOIN lh_data_platform_bronze.child_social.fact_cla AS fcl
        ON dp.dim_person_id = fcl.dim_person_id
    JOIN lh_data_platform_bronze.child_social.fact_referrals AS fr
        ON dp.dim_person_id = fr.dim_person_id
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.cla_episode")


# In[7]:


# cdm.cp_episode
# NOTE: the referrals join uses dp.LEGACY_ID = fr.dim_person_id (unlike CIN/CLA,
# which join dim_person_id = dim_person_id). Kept as-is, but check it's intended.
df = spark.sql("""
    SELECT DISTINCT
        dp.LEGACY_ID AS PersonID,
        fcp.FACT_CP_PLAN_ID AS CPEpisodeID,
        TO_DATE(fcp.START_DTTM, 'yyyy-MM-dd HH:mm:ss') AS CPStartDate,
        TO_DATE(fcp.END_DTTM, 'yyyy-MM-dd HH:mm:ss') AS CPEndDate,
        CASE
            WHEN fr.group_referral_id IS NULL THEN
                concat_ws('', 'CP', CAST(fr.dim_person_id AS STRING),
                          date_format(to_timestamp(fcp.START_DTTM, 'yyyy-MM-dd HH:mm:ss'), 'yyyyMMdd'))
            ELSE
                concat_ws('', 'CP', CAST(fr.group_referral_id AS STRING),
                          date_format(to_timestamp(fcp.START_DTTM, 'yyyy-MM-dd HH:mm:ss'), 'yyyyMMdd'))
        END AS GroupID
    FROM lh_data_platform_bronze.child_social.dim_person AS dp
    JOIN lh_data_platform_bronze.child_social.fact_cp_plan AS fcp
        ON dp.dim_person_id = fcp.dim_person_id
    LEFT JOIN lh_data_platform_bronze.child_social.fact_referrals AS fr
        ON dp.LEGACY_ID = fr.dim_person_id
    WHERE dp.LEGACY_ID <> 'Unknown'
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.cp_episode")


# In[8]:


# cdm.intervention_person
df = spark.sql("""
    SELECT
        dp.LEGACY_ID AS PersonID,
        dp.FORENAME AS FirstName,
        dp.SURNAME AS Surname,
        dp.BIRTH_DTTM AS DOB,
        dp.GENDER_DESCRIPTION AS Gender
    FROM lh_data_platform_bronze.child_social.dim_person dp
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.intervention_person")


# In[9]:


# cdm.school_person
# NOTE: in LIKE, '_' is a single-character wildcard, so '%G_%' excludes any ID
# containing 'G' followed by any character. Kept as-is; see notes.
df = spark.sql("""
    SELECT
        dp.UPN AS UPN,
        dp.LEGACY_ID AS SchoolPersonID,
        dp.FORENAME AS FirstName,
        dp.SURNAME AS Surname,
        dp.BIRTH_DTTM AS DOB,
        dp.GENDER_DESCRIPTION AS Gender
    FROM lh_data_platform_bronze.child_social.dim_person dp
    WHERE dp.LEGACY_ID NOT LIKE '%G_%'
      AND dp.LEGACY_ID NOT LIKE '%eStart%'
      AND dp.UPN != 'Unknown'
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.school_person")


# In[10]:


# cdm.eh_episode
df = spark.sql("""
    SELECT DISTINCT
        dp.SURNAME AS Surname,
        date_format(dp.BIRTH_DTTM, 'yyyy-MM-dd') AS DOB,
        dp.GENDER_DESCRIPTION AS Gender,
        dp.LEGACY_ID AS PersonID,
        dp.other_identifier_3 AS FamilyID,
        fce.FACT_CAF_EPISODE_ID AS EHEpisodeID,
        date_format(fce.EPISODE_START_DTTM, 'yyyy-MM-dd') AS EHStartDate,
        date_format(fce.EPISODE_END_DTTM, 'yyyy-MM-dd') AS EHEndDate,
        'REF' AS EHClosureReason,
        dp.other_identifier_3 AS GroupID
    FROM lh_data_platform_bronze.child_social.dim_person AS dp
    JOIN lh_data_platform_bronze.child_social.fact_caf_episode AS fce
        ON dp.dim_person_id = fce.dim_person_id
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.eh_episode")


# In[11]:


# cdm.exclusion_event
# fact_school_exclusion lives in the bronze EDUCATION schema (was child_social).
df = spark.sql("""
    SELECT
        dp.UPN AS UPN,
        dp.legacy_id AS SchoolPersonID,
        fsc.START_DTTM AS ExclusionStartdate,
        fsc.END_DTTM AS ExclusionEndDate,
        fsc.EXCLUSION_IN_DAYS AS DaysExcluded,
        fsc.DIM_LOOKUP_EXCLUSION_REASON_DESC AS ExclusionEvent
    FROM lh_data_platform_bronze.child_social.dim_person dp
    INNER JOIN lh_data_platform_bronze.education.fact_school_exclusion fsc
        ON dp.dim_person_id = fsc.dim_person_id
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.exclusion_event")


# In[12]:


# cdm.supporting_families_person
df = spark.sql("""
    SELECT
        dp.legacy_id AS PersonID,
        dp.UPN AS UPN,
        dp.other_identifier_3 AS FamilyID,
        fce.GROUP_EPISODE_ID AS GroupID,
        dp.forename AS FirstName,
        dp.surname AS Surname,
        dp.birth_dttm AS DOB,
        dp.GENDER_DESCRIPTION AS Gender
    FROM lh_data_platform_bronze.child_social.dim_person dp
    INNER JOIN lh_data_platform_bronze.child_social.fact_caf_episode fce
        ON dp.dim_person_id = fce.dim_person_id
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.supporting_families_person")


# In[13]:


# cdm.pupil_on_roll
df = spark.sql("""
WITH base AS (
  SELECT
    f.dim_person_id,
    p.dim_person_upn,
    to_date(f.attendance_dttm) AS attendance_date,
    f.actual_attendance,
    f.possible_attendance,
    f.absence
  FROM lh_data_platform_bronze.education.fact_client_attendance f
  LEFT JOIN lh_data_platform_bronze.education.fact_client_attendance_summary p
    ON f.dim_person_id = p.dim_person_id
  WHERE f.attendance_dttm IS NOT NULL
),
tagged AS (
  SELECT
    dim_person_id,
    dim_person_upn,
    -- Academic year: Sep–Aug
    CASE
      WHEN month(attendance_date) >= 9 THEN year(attendance_date)
      ELSE year(attendance_date) - 1
    END AS `year`,
    -- Term by month
    CASE
      WHEN month(attendance_date) BETWEEN 9 AND 12 THEN 1
      WHEN month(attendance_date) BETWEEN 1 AND 4  THEN 2
      WHEN month(attendance_date) BETWEEN 5 AND 8  THEN 3
      ELSE NULL
    END AS term,
    actual_attendance,
    possible_attendance,
    absence
  FROM base
)
SELECT
  dim_person_id,
  dim_person_upn,
  `year`,
  term,
  SUM(actual_attendance)   AS termlysessionsauthorised,
  SUM(possible_attendance) AS termlysessionspossible,
  SUM(absence)             AS termlysessionsunauthorised
FROM tagged
GROUP BY dim_person_id, dim_person_upn, `year`, term
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.pupil_on_roll")


# In[14]:


# cdm.school_term_dates (static reference data)
df = spark.sql("""
SELECT
    col1 AS Year,
    col2 AS Term,
    to_date(col3, 'dd/MM/yyyy') AS TermStartDate,
    to_date(col4, 'dd/MM/yyyy') AS TermEndDate
FROM VALUES
    ('2015/16', 1, '01/09/2015', '31/12/2015'),
    ('2015/16', 2, '01/01/2016', '30/04/2016'),
    ('2015/16', 3, '01/05/2016', '31/08/2016'),
    ('2016/17', 1, '01/09/2016', '31/12/2016'),
    ('2016/17', 2, '01/01/2017', '30/04/2017'),
    ('2016/17', 3, '01/05/2017', '31/08/2017'),
    ('2017/18', 1, '01/09/2017', '31/12/2017'),
    ('2017/18', 2, '01/01/2018', '30/04/2018'),
    ('2017/18', 3, '01/05/2018', '31/08/2018'),
    ('2018/19', 1, '01/09/2018', '31/12/2018'),
    ('2018/19', 2, '01/01/2019', '30/04/2019'),
    ('2018/19', 3, '01/05/2019', '31/08/2019'),
    ('2019/20', 1, '01/09/2019', '31/12/2019'),
    ('2019/20', 2, '01/01/2020', '30/04/2020'),
    ('2019/20', 3, '01/05/2020', '31/08/2020'),
    ('2020/21', 1, '01/09/2020', '31/12/2020'),
    ('2020/21', 2, '01/01/2021', '30/04/2021'),
    ('2020/21', 3, '01/05/2021', '31/08/2021'),
    ('2021/22', 1, '01/09/2021', '31/12/2021'),
    ('2021/22', 2, '01/01/2022', '30/04/2022'),
    ('2021/22', 3, '01/05/2022', '31/08/2022'),
    ('2022/23', 1, '01/09/2022', '31/12/2022'),
    ('2022/23', 2, '01/01/2023', '30/04/2023'),
    ('2022/23', 3, '01/05/2023', '31/08/2023'),
    ('2023/24', 1, '01/09/2023', '31/12/2023'),
    ('2023/24', 2, '01/01/2024', '30/04/2024'),
    ('2023/24', 3, '01/05/2024', '31/08/2024'),
    ('2024/25', 1, '01/09/2024', '31/12/2024'),
    ('2024/25', 2, '01/01/2025', '30/04/2025'),
    ('2024/25', 3, '01/05/2025', '31/08/2025'),
    ('2025/26', 1, '01/09/2025', '31/12/2025'),
    ('2025/26', 2, '01/01/2026', '30/04/2026'),
    ('2025/26', 3, '01/05/2026', '31/08/2026'),
    ('2026/27', 1, '01/09/2026', '31/12/2026'),
    ('2026/27', 2, '01/01/2027', '30/04/2027'),
    ('2026/27', 3, '01/05/2027', '31/08/2027')
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.school_term_dates")


# In[15]:


# cdm.attendance_session_codes (static reference data)
# Built as a DataFrame: the original T-SQL [bracket] aliases are invalid in Spark,
# and the '\' code was being swallowed by Python string escaping.
# 'Physical Meaning' renamed to PhysicalMeaning (Delta disallows spaces by default).
attendance_codes = [
    ("G", "Family holiday (not agreed)", "Unauthorised Absence", "Out for whole session"),
    ("N", "No reason yet provided for absence", "Unauthorised Absence", "Out for whole session"),
    ("O", "Unauthorised Abs", "Unauthorised Absence", "Out for whole session"),
    ("U", "Late (after registers closed)", "Unauthorised Absence", "Out for whole session"),
    ("/", "Present (AM)", "Present", "In for whole session"),
    ("\\", "Present (PM)", "Present", "In for whole session"),
    ("B", "Education off site (no Dual reg)", "Approved Education Activity", "Out for whole session"),
    ("C", "Other authorised circumstances", "Authorised Absence", "Out for whole session"),
    ("D", "Dual registration", "Approved Education Activity", "Out for whole session"),
    ("E", "Excluded", "Authorised Absence", "Out for whole session"),
    ("F", "Extended family holiday (agreed)", "Authorised Absence", "Out for whole session"),
    ("H", "Family holiday (agreed)", "Authorised Absence", "Out for whole session"),
    ("I", "Illness", "Authorised Absence", "Out for whole session"),
    ("J", "Interview", "Approved Education Activity", "Out for whole session"),
    ("L", "Late (before registers closed)", "Present", "Late for session"),
    ("M", "Medical/Dental appointments", "Authorised Absence", "Out for whole session"),
    ("P", "Approved sporting activity", "Approved Education Activity", "In for whole session"),
    ("R", "Religious observance", "Authorised Absence", "Out for whole session"),
    ("S", "Study leave", "Authorised Absence", "Out for whole session"),
    ("T", "Traveller absence", "Authorised Absence", "Out for whole session"),
    ("V", "Educational visit or trip", "Approved Education Activity", "Out for whole session"),
    ("W", "Work experience", "Approved Education Activity", "Out for whole session"),
    ("#", "School closed to pupils & staff", "Attendance not required", "Out for whole session"),
    ("Y", "Enforced closure", "Attendance not required", "Out for whole session"),
    ("X", "Non-compulsory school age absence", "Attendance not required", "Out for whole session"),
    ("Z", "Pupil not on roll", "Attendance not required", "Out for whole session"),
    ("-", "All should attend/No mark recorded", "No mark", "Out for whole session"),
]

attendance_codes_schema = StructType([
    StructField("Codes", StringType(), False),
    StructField("Description", StringType(), True),
    StructField("Meaning", StringType(), True),
    StructField("PhysicalMeaning", StringType(), True),
])

df = spark.createDataFrame(attendance_codes, attendance_codes_schema)

OverwriteLoad(df, "lh_data_platform_silver.cdm.attendance_session_codes")


# In[16]:


# ============================================================
# STAGE 2 — Depends on Stage 1
# ============================================================

# cdm.supporting_families_event   <- eh_episode
df = spark.sql("""
    WITH _allEvents AS (
        /* First EH event closed within the window, used as the SF event.
           Only events that closed over 6 months ago can be claimed. */
        SELECT
            PersonID,
            GroupID,
            FamilyID,
            EHStartDate AS SFStartDate,
            EHEndDate AS SFEndDate,
            'EH' AS Service,
            EHClosureReason AS SFClosureReason,
            ROW_NUMBER() OVER (PARTITION BY PersonID ORDER BY EHStartDate ASC) AS rownum
        FROM lh_data_platform_silver.cdm.eh_episode
        WHERE EHEndDate > add_months(current_date(), -12 * 5)
          AND EHEndDate < add_months(current_date(), -6)
    )
    SELECT
        PersonID,
        GroupID,
        FamilyID,
        SFStartDate,
        SFEndDate,
        Service,
        SFClosureReason
    FROM _allEvents
    WHERE rownum = 1
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.supporting_families_event")


# In[17]:


# cdm.school_event   <- pupil_on_roll
df = spark.sql("""
    SELECT
        p.dim_person_upn AS UPN,
        p.dim_person_id AS SchoolPersonID,
        p.year AS Year,
        p.term AS Term,
        p.termlysessionspossible AS AvailableSessions,
        p.termlysessionsauthorised AS AuthorisedSessions,
        p.termlysessionsunauthorised AS UnauthorisedSessions
    FROM lh_data_platform_silver.cdm.pupil_on_roll AS p
    WHERE p.year IN ('2023', '2024', '2025')
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.school_event")


# In[18]:


# cdm.vw_school_term_dates   <- school_term_dates
df = spark.sql("""
WITH terms_cte AS (
  SELECT
    ROW_NUMBER() OVER (ORDER BY TermStartDate DESC) AS RowNum,
    CASE WHEN current_date() BETWEEN TermStartDate AND TermEndDate THEN 1 ELSE 0 END AS IsCurrent,
    -- '2023/24' -> StartYear=2023, EndYear=2024
    CAST(substring(regexp_replace(`Year`, '[^0-9]', ''), 1, 4) AS INT) AS StartYear,
    CAST(concat('20', substring(regexp_replace(`Year`, '[^0-9]', ''), 5, 2)) AS INT) AS EndYear,
    `Year`,
    Term,
    TermStartDate,
    TermEndDate
  FROM lh_data_platform_silver.cdm.school_term_dates
),
terms_with_key AS (
  SELECT
    RowNum,
    IsCurrent,
    CONCAT(CAST(StartYear AS STRING), CAST(EndYear AS STRING), '0', CAST(Term AS STRING)) AS TermKey,
    `Year`,
    Term,
    TermStartDate,
    TermEndDate
  FROM terms_cte
),
cur AS (
  SELECT MAX(CASE WHEN IsCurrent = 1 THEN RowNum END) AS CurrentRowNum
  FROM terms_with_key
)
SELECT
  t.TermKey,
  t.`Year`,
  t.Term,
  t.TermStartDate,
  t.TermEndDate,
  COALESCE(c.CurrentRowNum, 0) - t.RowNum AS RelativeTerm
FROM terms_with_key t
CROSS JOIN cur c
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.vw_school_term_dates")


# In[19]:


# ============================================================
# STAGE 3 — Depends on Stages 1–2
# ============================================================

# cdm.vw_school_event   <- school_event
df = spark.sql("""
SELECT
  UPN,
  SchoolPersonID,
  Year,
  Term,
  AvailableSessions,
  AuthorisedSessions,
  UnauthorisedSessions,
  CONCAT(
    CAST(CAST(Year AS INT) AS STRING),
    CAST(CAST(Year AS INT) + 1 AS STRING),
    '0',
    CAST(Term AS STRING)
  ) AS TermKey
FROM lh_data_platform_silver.cdm.school_event
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.vw_school_event")


# In[20]:


# cdm.vw_exclusion_event   <- exclusion_event, vw_school_term_dates
df = spark.sql("""
SELECT
    exclusion.*,
    term.TermKey
FROM lh_data_platform_silver.cdm.exclusion_event AS exclusion
JOIN lh_data_platform_silver.cdm.vw_school_term_dates AS term
    ON term.TermStartDate <= exclusion.ExclusionStartdate
   AND term.TermEndDate > exclusion.ExclusionStartdate
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.vw_exclusion_event")


# In[21]:


# cdm.vw_supporting_families_person   <- supporting_families_person, supporting_families_event
df = spark.sql("""
SELECT
  sfPerson.*,
  CAST(floor(months_between(sfEvent.SFStartDate, sfPerson.DOB) / 12) AS INT) AS AgeAtSFStartDate,
  CAST(floor(months_between(sfEvent.SFEndDate,   sfPerson.DOB) / 12) AS INT) AS AgeAtSFEndDate
FROM lh_data_platform_silver.cdm.supporting_families_person AS sfPerson
JOIN lh_data_platform_silver.cdm.supporting_families_event AS sfEvent
  ON sfEvent.PersonID = sfPerson.PersonID
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.vw_supporting_families_person")


# In[22]:


# cdm.vw_relative_term_dates
#   <- school_person, supporting_families_person, supporting_families_event, vw_school_term_dates
df = spark.sql("""
SELECT
    person.UPN,
    person.SchoolPersonID,
    startTerm.RelativeTerm AS RelativeStartTerm,
    startTerm.TermKey AS StartTermKey,
    endTerm.RelativeTerm AS RelativeEndTerm,
    endTerm.TermKey AS EndTermKey
FROM lh_data_platform_silver.cdm.school_person AS person
JOIN lh_data_platform_silver.cdm.supporting_families_person AS sfPerson
    ON sfPerson.PersonID = person.SchoolPersonID
JOIN lh_data_platform_silver.cdm.supporting_families_event AS sfEvent
    ON sfEvent.PersonID = sfPerson.PersonID
JOIN lh_data_platform_silver.cdm.vw_school_term_dates AS startTerm
    ON startTerm.TermStartDate <= sfEvent.SFStartDate AND startTerm.TermEndDate > sfEvent.SFStartDate
JOIN lh_data_platform_silver.cdm.vw_school_term_dates AS endTerm
    ON endTerm.TermStartDate < sfEvent.SFEndDate AND endTerm.TermEndDate >= sfEvent.SFEndDate
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.vw_relative_term_dates")


# In[23]:


# ============================================================
# STAGE 4 — Depends on Stages 1–3
# ============================================================

# cdm.education_exclusions
#   <- vw_exclusion_event, school_person, supporting_families_person,
#      supporting_families_event, vw_school_term_dates, vw_relative_term_dates
df = spark.sql("""
WITH _exclusions AS
(
    /* One row per child per term; terms with no ExclusionEvent record get 0 days. */
    SELECT
        allExc.UPN,
        allExc.SchoolPersonID,
        allExc.GroupID,
        allExc.TermKey,
        allExc.RelativeTerm,
        SUM(COALESCE(exclusions.DaysExcluded, 0)) AS DaysExcluded
    FROM lh_data_platform_silver.cdm.vw_exclusion_event AS exclusions
    RIGHT JOIN
        (
            SELECT
                terms.TermKey, terms.RelativeTerm,
                person.UPN, person.SchoolPersonID, sfEvent.GroupID
            FROM lh_data_platform_silver.cdm.school_person AS person
            JOIN lh_data_platform_silver.cdm.supporting_families_person AS sfPerson
                ON sfPerson.PersonID = person.SchoolPersonID
            JOIN lh_data_platform_silver.cdm.supporting_families_event AS sfEvent
                ON sfEvent.PersonID = sfPerson.PersonID
            FULL OUTER JOIN lh_data_platform_silver.cdm.vw_school_term_dates AS terms ON 1 = 1
            JOIN lh_data_platform_silver.cdm.vw_relative_term_dates AS startTerm
                ON startTerm.SchoolPersonID = person.SchoolPersonID
            JOIN lh_data_platform_silver.cdm.vw_relative_term_dates AS endTerm
                ON endTerm.SchoolPersonID = person.SchoolPersonID
            /* 0 is current term; from 2 complete terms before the start term up to the last complete term */
            WHERE terms.RelativeTerm BETWEEN startTerm.RelativeStartTerm - 3 AND -1
        ) allExc
        ON allExc.SchoolPersonID = exclusions.SchoolPersonID AND allExc.TermKey = exclusions.TermKey
    GROUP BY
        allExc.UPN,
        allExc.SchoolPersonID,
        allExc.GroupID,
        allExc.TermKey,
        allExc.RelativeTerm
),
_rankedExclusions AS
(
    /* Rolling two-term totals, ranked to find the high point to compare to. */
    SELECT *,
    RANK() OVER (PARTITION BY SchoolPersonID ORDER BY TwoMonthTotal DESC, RelativeTerm DESC) AS MostExclusions
    FROM (
        SELECT exclusions.*,
        SUM(DaysExcluded) OVER (PARTITION BY exclusions.SchoolPersonID ORDER BY exclusions.RelativeTerm
                                ROWS BETWEEN 1 PRECEDING AND CURRENT ROW) AS TwoMonthTotal
        FROM _exclusions AS exclusions
        JOIN lh_data_platform_silver.cdm.vw_relative_term_dates AS endTerm
            ON exclusions.SchoolPersonID = endTerm.SchoolPersonID
        /* only rank terms up to the end of the supporting families intervention */
        WHERE RelativeTerm <= endTerm.RelativeEndTerm
    ) r
)
SELECT DISTINCT
    excl.UPN,
    excl.SchoolPersonID,
    excl.GroupID,
    CAST(topExclusions.TwoMonthTotal / 2 AS DECIMAL(4,1)) AS HighestAverageOverTwoTerms,
    previousTermExclusions.DaysExcluded AS DaysExcludedLastTerm,
    previousPreviousTermExclusions.DaysExcluded AS DaysExcludedTermBeforeLast
FROM _exclusions AS excl
JOIN
    (
        SELECT UPN, SchoolPersonID, TwoMonthTotal
        FROM _rankedExclusions WHERE MostExclusions = 1
    ) AS topExclusions
    ON topExclusions.UPN = excl.UPN
JOIN
    (
        SELECT UPN, SchoolPersonID, SUM(DaysExcluded) AS DaysExcluded
        FROM _exclusions WHERE RelativeTerm = -1
        GROUP BY UPN, SchoolPersonID
    ) AS previousTermExclusions
    ON previousTermExclusions.UPN = excl.UPN
JOIN
    (
        SELECT UPN, SchoolPersonID, SUM(DaysExcluded) AS DaysExcluded
        FROM _exclusions WHERE RelativeTerm = -2
        GROUP BY UPN, SchoolPersonID
    ) AS previousPreviousTermExclusions
    ON previousPreviousTermExclusions.UPN = excl.UPN
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.education_exclusions")


# In[24]:


# cdm.keeping_children_safe_social_care
#   <- supporting_families_event, eh_episode, cin_episode
# T-SQL DATEDIFF/DATEADD replaced with Spark-native datediff(end, start) / add_months.
df = spark.sql("""
SELECT
    sfEvent.PersonID,
    sfEvent.FamilyID AS FamilyID,
    sfEvent.GroupID AS SFGroupID,
    sfEvent.SFStartDate,
    sfEvent.SFEndDate,
    regressions.RegressionGroupID,
    regressions.RegressionType,
    regressions.EpisodeID,
    regressions.EpisodeStart,
    regressions.EpisodeEnd
FROM lh_data_platform_silver.cdm.supporting_families_event AS sfEvent
LEFT OUTER JOIN
(
    SELECT
        firstep.PersonID, firstep.RegressionGroupID,
        firstep.RegressionType, firstep.EpisodeID, firstep.EpisodeStart, firstep.EpisodeEnd
    FROM
    (
        SELECT
            ep.PersonID, ep.GroupID AS RegressionGroupID, ep.EpisodeType AS RegressionType,
            EpisodeID, EpisodeStart, EpisodeEnd
        FROM
        (
            SELECT
                allepisodes.PersonID, allepisodes.GroupID, allepisodes.EpisodeType,
                allepisodes.EpisodeID, allepisodes.EpisodeStart, allepisodes.EpisodeEnd,
                ROW_NUMBER() OVER (PARTITION BY allepisodes.PersonID ORDER BY EpisodeStart ASC) AS rownum
            FROM
            (
                SELECT eh.PersonID, eh.GroupID, 'EH' AS EpisodeType, eh.EHEpisodeID AS EpisodeID,
                       eh.EHStartDate AS EpisodeStart, eh.EHEndDate AS EpisodeEnd
                FROM lh_data_platform_silver.cdm.eh_episode AS eh
                UNION ALL
                SELECT cin.PersonID, cin.GroupID, 'CIN' AS EpisodeType, cin.CINEpisodeID AS EpisodeID,
                       cin.CINStartDate AS EpisodeStart, cin.CINEndDate AS EpisodeEnd
                FROM lh_data_platform_silver.cdm.cin_episode AS cin
                -- UNION ALL
                -- SELECT cp.PersonID, cp.GroupID, 'CP' AS EpisodeType, cp.CPEpisodeID AS EpisodeID,
                --        cp.CPStartDate AS EpisodeStart, cp.CPEndDate AS EpisodeEnd
                -- FROM lh_data_platform_silver.cdm.cp_episode AS cp
                -- UNION ALL
                -- SELECT cla.PersonID, cla.GroupID, 'CLA' AS EpisodeType, cla.CLAEpisodeID AS EpisodeID,
                --        cla.CLAStartDate AS EpisodeStart, cla.CLAEndDate AS EpisodeEnd
                -- FROM lh_data_platform_silver.cdm.cla_episode AS cla
            ) allepisodes
            JOIN lh_data_platform_silver.cdm.supporting_families_event AS sfEvent
                ON sfEvent.PersonID = allepisodes.PersonID
            WHERE datediff(sfEvent.SFEndDate, allepisodes.EpisodeStart) < 0
              AND datediff(add_months(sfEvent.SFEndDate, 6), allepisodes.EpisodeStart) > 0
        ) ep
        WHERE rownum = 1
    ) firstep
) AS regressions
    ON regressions.PersonID = sfEvent.PersonID
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.keeping_children_safe_social_care")


# In[25]:


# cdm.keeping_children_safe_missing_from_home
#   <- mfh_episode, supporting_families_person, supporting_families_event
df = spark.sql("""
SELECT
    sfPerson.PersonID,
    sfEvent.FamilyID,
    sfEvent.GroupID,
    sfEvent.SFStartDate,
    sfEvent.SFEndDate,
    CASE WHEN
        SUM(CASE WHEN mfh.MfHEndDate > add_months(sfEvent.SFStartDate, -12)
                  AND mfh.MfHEndDate <= sfEvent.SFStartDate
            THEN 1 ELSE 0 END) >= 1
        THEN 1 ELSE 0 END AS NeedIdentified,
    CASE WHEN
        SUM(CASE WHEN mfh.MfHEndDate BETWEEN add_months(sfEvent.SFEndDate, -1) AND sfEvent.SFEndDate
            THEN 1 ELSE 0 END) >= 1
        THEN 1 ELSE 0 END AS MfHMonth1BeforeClose,
    CASE WHEN
        SUM(CASE WHEN mfh.MfHStartDate > sfEvent.SFEndDate
                  AND mfh.MfHStartDate <= add_months(sfEvent.SFEndDate, 6)
            THEN 1 ELSE 0 END) >= 1
        THEN 1 ELSE 0 END AS MfHMonth6AfterClose
FROM lh_data_platform_silver.cdm.mfh_episode AS mfh
RIGHT JOIN lh_data_platform_silver.cdm.supporting_families_person AS sfPerson
    ON sfPerson.PersonID = mfh.PersonID
JOIN lh_data_platform_silver.cdm.supporting_families_event AS sfEvent
    ON sfEvent.PersonID = sfPerson.PersonID
GROUP BY sfPerson.PersonID, sfEvent.FamilyID, sfEvent.GroupID, sfEvent.SFStartDate, sfEvent.SFEndDate
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.keeping_children_safe_missing_from_home")


# In[26]:


# cdm.vw_attendance
#   <- vw_school_event, school_person, supporting_families_person,
#      supporting_families_event, vw_school_term_dates, vw_relative_term_dates
df = spark.sql("""
SELECT DISTINCT
    allTerms.UPN,
    allTerms.SchoolPersonID,
    allTerms.FamilyID,
    allTerms.GroupID,
    allTerms.TermKey,
    schoolEvent.AvailableSessions,
    schoolEvent.AuthorisedSessions,
    schoolEvent.UnauthorisedSessions,
    allTerms.RelativeTerm,
    allTerms.RelativeStartTerm,
    allTerms.RelativeEndTerm,
    allTerms.SFStartDate,
    allTerms.SFEndDate
FROM lh_data_platform_silver.cdm.vw_school_event AS schoolEvent
JOIN (
    SELECT
        terms.TermKey,
        terms.RelativeTerm,
        startTerm.RelativeStartTerm,
        endTerm.RelativeEndTerm,
        person.UPN,
        person.SchoolPersonID,
        sfEvent.FamilyID,
        sfEvent.GroupID,
        sfEvent.SFStartDate,
        sfEvent.SFEndDate
    FROM lh_data_platform_silver.cdm.school_person AS person
    JOIN lh_data_platform_silver.cdm.supporting_families_person AS sfPerson
      ON upper(trim(sfPerson.UPN)) = upper(trim(person.UPN))
    JOIN lh_data_platform_silver.cdm.supporting_families_event AS sfEvent
      ON sfEvent.PersonID = sfPerson.PersonID
    JOIN lh_data_platform_silver.cdm.vw_school_term_dates AS terms
      ON 1 = 1
    JOIN lh_data_platform_silver.cdm.vw_relative_term_dates AS startTerm
      ON startTerm.SchoolPersonID = person.SchoolPersonID
    JOIN lh_data_platform_silver.cdm.vw_relative_term_dates AS endTerm
      ON endTerm.SchoolPersonID = person.SchoolPersonID
    WHERE terms.RelativeTerm >= startTerm.RelativeStartTerm - 3
) allTerms
ON upper(trim(allTerms.UPN)) = upper(trim(schoolEvent.UPN))
AND CAST(allTerms.TermKey AS STRING) = CAST(schoolEvent.TermKey AS STRING)
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.vw_attendance")


# In[27]:


# ============================================================
# STAGE 5 — Attendance chain (strictly sequential)
# ============================================================

# cdm.vw_ranked_attendance   <- vw_attendance, vw_relative_term_dates
df = spark.sql("""
SELECT
    *,
    RANK() OVER (PARTITION BY SchoolPersonID ORDER BY AttendanceOverTwoMonthsUnauth ASC) AS RankedUnauthorisedAbsense,
    RANK() OVER (PARTITION BY SchoolPersonID ORDER BY AttendanceOverTwoMonthsAuth ASC) AS RankedAuthorisedUnauthorisedAbsense
FROM (
    SELECT
        sumEvent.*,
        (CASE
            WHEN sumEvent.TotalAvailableOver2Months != 0 THEN
                (CAST(sumEvent.TotalAvailableOver2Months AS DECIMAL(10,2)) - CAST(sumEvent.TotalUnauthOver2Months AS DECIMAL(10,2)))
                / NULLIF(CAST(sumEvent.TotalAvailableOver2Months AS DECIMAL(10,2)), 0)
            ELSE NULL
        END) AS AttendanceOverTwoMonthsUnauth,
        (CASE
            WHEN sumEvent.TotalAvailableOver2Months != 0 THEN
                (CAST(sumEvent.TotalAvailableOver2Months AS DECIMAL(10,2)) - CAST(sumEvent.TotalUnauthOver2Months AS DECIMAL(10,2)) - CAST(sumEvent.TotalAuthOver2Months AS DECIMAL(10,2)))
                / NULLIF(CAST(sumEvent.TotalAvailableOver2Months AS DECIMAL(10,2)), 0)
            ELSE NULL
        END) AS AttendanceOverTwoMonthsAuth
    FROM (
        SELECT
            attendance.*,
            SUM(UnauthorisedSessions) OVER (PARTITION BY attendance.SchoolPersonID ORDER BY RelativeTerm ROWS BETWEEN 1 PRECEDING AND CURRENT ROW) AS TotalUnauthOver2Months,
            SUM(AuthorisedSessions)   OVER (PARTITION BY attendance.SchoolPersonID ORDER BY RelativeTerm ROWS BETWEEN 1 PRECEDING AND CURRENT ROW) AS TotalAuthOver2Months,
            SUM(AvailableSessions)    OVER (PARTITION BY attendance.SchoolPersonID ORDER BY RelativeTerm ROWS BETWEEN 1 PRECEDING AND CURRENT ROW) AS TotalAvailableOver2Months,
            MIN(RelativeTerm)         OVER (PARTITION BY attendance.SchoolPersonID) AS FirstTerm
        FROM lh_data_platform_silver.cdm.vw_attendance AS attendance
        JOIN lh_data_platform_silver.cdm.vw_relative_term_dates AS endTerm
            ON attendance.SchoolPersonID = endTerm.SchoolPersonID
        -- WHERE attendance.RelativeTerm < endTerm.RelativeEndTerm
        WHERE attendance.RelativeTerm > endTerm.RelativeEndTerm
    ) sumEvent
) r
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.vw_ranked_attendance")


# In[28]:


# cdm.education_attendance_calculations   <- vw_ranked_attendance, vw_attendance
df = spark.sql("""
SELECT DISTINCT
    att.UPN,
    att.SchoolPersonID,
    att.FamilyID,
    att.GroupID,
    att.SFStartDate,
    att.SFEndDate,
    unauthorisedAbsence.TermKey AS LowestUnauthTermKey,
    unauthorisedAbsence.TotalAvailableOver2Months AS LowestUnauthTermsTotalAvailable,
    unauthorisedAbsence.TotalUnauthOver2Months AS LowestUnauthTermsTotalUnauthAbsense,
    unauthorisedAbsence.TotalAuthOver2Months AS LowestUnauthTermsTotalAuthAbsense,
    unauthorisedAbsence.AttendanceOverTwoMonthsUnauth AS LowestAttendanceUnauthPercent,
    authorisedAbsence.TermKey AS LowestAuthTermKey,
    authorisedAbsence.TotalAvailableOver2Months AS LowestAuthTermsTotalAvailable,
    authorisedAbsence.TotalUnauthOver2Months AS LowestAuthTermsTotalUnauthAbsense,
    authorisedAbsence.TotalAuthOver2Months AS LowestAuthTermsTotalAuthAbsense,
    authorisedAbsence.AttendanceOverTwoMonthsAuth AS LowestAttendanceAuthPercent,
    closeTerm.TermKey AS CloseTerm,
    closeTerm.AvailableSessions AS CloseTermAvailableSessions,
    closeTerm.UnauthorisedSessions AS CloseTermUnauthorisedSessions,
    closeTerm.AuthorisedSessions AS CloseTermAuthorisedSessions,
    closeTerm.CloseTermAttendanceUnauthPercent,
    closeTerm.CloseTermAttendanceAuthAndUnauthPercent,
    nextTerm.TermKey AS NextTerm,
    nextTerm.AvailableSessions AS NextTermAvailableSessions,
    nextTerm.UnauthorisedSessions AS NextTermUnauthorisedSessions,
    nextTerm.AuthorisedSessions AS NextTermAuthorisedSessions,
    nextTerm.NextTermAttendanceUnauthPercent,
    nextTerm.NextTermAttendanceAuthAndUnauthPercent
FROM lh_data_platform_silver.cdm.vw_ranked_attendance AS att
JOIN (
    SELECT UPN, TermKey,
           TotalAvailableOver2Months, TotalUnauthOver2Months, TotalAuthOver2Months, AttendanceOverTwoMonthsUnauth
    FROM lh_data_platform_silver.cdm.vw_ranked_attendance
    WHERE RankedUnauthorisedAbsense = 1
) AS unauthorisedAbsence
    ON unauthorisedAbsence.UPN = att.UPN
JOIN (
    SELECT UPN, TermKey,
           TotalAvailableOver2Months, TotalUnauthOver2Months, TotalAuthOver2Months, AttendanceOverTwoMonthsAuth
    FROM lh_data_platform_silver.cdm.vw_ranked_attendance
    WHERE RankedAuthorisedUnauthorisedAbsense = 1
) AS authorisedAbsence
    ON authorisedAbsence.UPN = att.UPN
JOIN (
    SELECT UPN, TermKey,
           AvailableSessions, UnauthorisedSessions, AuthorisedSessions,
           (CASE WHEN AvailableSessions != 0 THEN
                (CAST(AvailableSessions AS DECIMAL(10,2)) - CAST(UnauthorisedSessions AS DECIMAL(10,2)))
                / CAST(AvailableSessions AS DECIMAL(10,2))
            ELSE NULL END) AS CloseTermAttendanceUnauthPercent,
           (CASE WHEN AvailableSessions != 0 THEN
                (CAST(AvailableSessions AS DECIMAL(10,2)) - CAST(UnauthorisedSessions AS DECIMAL(10,2)) - CAST(AuthorisedSessions AS DECIMAL(10,2)))
                / CAST(AvailableSessions AS DECIMAL(10,2))
            ELSE NULL END) AS CloseTermAttendanceAuthAndUnauthPercent
    FROM lh_data_platform_silver.cdm.vw_attendance
    -- WHERE RelativeTerm = RelativeEndTerm
) AS closeTerm
    ON closeTerm.UPN = att.UPN
JOIN (
    SELECT UPN, TermKey,
           AvailableSessions, UnauthorisedSessions, AuthorisedSessions,
           (CASE WHEN AvailableSessions != 0 THEN
                (CAST(AvailableSessions AS DECIMAL(10,2)) - CAST(UnauthorisedSessions AS DECIMAL(10,2)))
                / CAST(AvailableSessions AS DECIMAL(10,2))
            ELSE NULL END) AS NextTermAttendanceUnauthPercent,
           (CASE WHEN AvailableSessions != 0 THEN
                (CAST(AvailableSessions AS DECIMAL(10,2)) - CAST(UnauthorisedSessions AS DECIMAL(10,2)) - CAST(AuthorisedSessions AS DECIMAL(10,2)))
                / CAST(AvailableSessions AS DECIMAL(10,2))
            ELSE NULL END) AS NextTermAttendanceAuthAndUnauthPercent
    FROM lh_data_platform_silver.cdm.vw_attendance
    -- WHERE RelativeTerm = RelativeEndTerm + 1
) AS nextTerm
    ON nextTerm.UPN = att.UPN
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.education_attendance_calculations")


# In[29]:


# cdm.education_attendance   <- education_attendance_calculations
df = spark.sql("""
SELECT *
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY UPN ORDER BY SFStartDate) AS RowNum
    FROM lh_data_platform_silver.cdm.education_attendance_calculations
) RankedRows
WHERE RowNum = 1
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.education_attendance")


# In[30]:


# cdm.education_attendance_needsmet_calcs   <- education_attendance
df = spark.sql("""
WITH Calc AS (
  SELECT
    ea.*,
    -- Average over last 2 terms (auth absence)
    (
      (ea.CloseTermAvailableSessions + ea.NextTermAvailableSessions)
    - (ea.CloseTermUnauthorisedSessions + ea.NextTermUnauthorisedSessions)
    - (ea.CloseTermAuthorisedSessions + ea.NextTermAuthorisedSessions)
    ) * 1.0
    / CASE
        WHEN (ea.CloseTermAvailableSessions + ea.NextTermAvailableSessions) = 0 THEN NULL
        ELSE (ea.CloseTermAvailableSessions + ea.NextTermAvailableSessions)
      END AS Avg_Over_Last2_Terms_Auth_Absence,
    -- Average over last 2 terms (unauth absence)
    (
      (ea.CloseTermAvailableSessions + ea.NextTermAvailableSessions)
    - (ea.CloseTermUnauthorisedSessions + ea.NextTermUnauthorisedSessions)
    ) * 1.0
    / CASE
        WHEN (ea.CloseTermAvailableSessions + ea.NextTermAvailableSessions) = 0 THEN NULL
        ELSE (ea.CloseTermAvailableSessions + ea.NextTermAvailableSessions)
      END AS Avg_Over_Last2_Terms_Unauth_Absence
  FROM lh_data_platform_silver.cdm.education_attendance ea
),
Calc2 AS (
  SELECT
    ea.*,
    CASE
      WHEN ea.LowestAttendanceAuthPercent < 0.5 THEN ea.Avg_Over_Last2_Terms_Auth_Absence
      ELSE ea.Avg_Over_Last2_Terms_Unauth_Absence
    END AS Avg_Over_Last2_Terms_Incl_Authorised
  FROM Calc ea
),
Calc3 AS (
  SELECT
    c2.*,
    (c2.Avg_Over_Last2_Terms_Incl_Authorised - c2.LowestAttendanceAuthPercent) * 1.0
    / CASE WHEN c2.LowestAttendanceAuthPercent = 0 THEN NULL ELSE c2.LowestAttendanceAuthPercent END
    AS PercentageIncrease
  FROM Calc2 c2
)
SELECT
  ea.*,
  CASE WHEN ea.LowestAttendanceUnauthPercent < 0.9 THEN 'Yes' ELSE 'No' END AS `Attendance_1_Need`,
  CASE WHEN ea.Avg_Over_Last2_Terms_Incl_Authorised > 0.9 THEN 'Yes' ELSE 'No' END AS `Attendance_1_Need_Met_Individual`,
  CASE WHEN ea.LowestAttendanceAuthPercent < 0.5 THEN 'Yes' ELSE 'No' END AS `Attendance_2_Need`,
  CASE
    WHEN ea.LowestAttendanceAuthPercent < 0.5
      THEN CASE WHEN ea.PercentageIncrease > 0.3 THEN 1 ELSE -1 END
    ELSE 100
  END AS `Attendance_2_Need_Met`,
  CASE
    WHEN (CASE WHEN ea.LowestAttendanceAuthPercent < 0.5
               THEN CASE WHEN ea.PercentageIncrease > 0.3 THEN 1 ELSE -1 END
               ELSE 100 END) = -1 THEN 'No'
    WHEN (CASE WHEN ea.LowestAttendanceAuthPercent < 0.5
               THEN CASE WHEN ea.PercentageIncrease > 0.3 THEN 1 ELSE -1 END
               ELSE 100 END) = 1 THEN 'Yes'
    ELSE 'N/A'
  END AS `Attendance_2_Need_Met_Individual`
FROM Calc3 ea
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.education_attendance_needsmet_calcs")


# In[31]:


# cdm.education_attendance_needsmet_summary_detail   <- education_attendance_needsmet_calcs
df = spark.sql("""
SELECT
    FamilyID,
    GroupID,
    SchoolPersonID,
    Attendance_1_Need,
    Attendance_1_Need_Met_Individual,
    Attendance_2_Need,
    Attendance_2_Need_Met,
    Attendance_2_Need_Met_Individual
FROM lh_data_platform_silver.cdm.education_attendance_needsmet_calcs
ORDER BY FamilyID
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.education_attendance_needsmet_summary_detail")


# In[32]:


# ============================================================
# STAGE 6 — Pass/fail outputs
# ============================================================

# cdm.vw_individual_attendance_pass_fail
#   <- keeping_children_safe_social_care, education_attendance_needsmet_summary_detail
df = spark.sql("""
WITH WithNeedMet AS (
    SELECT *,
        CASE WHEN EpisodeID IS NULL THEN 1 ELSE -1 END AS NeedMet
    FROM lh_data_platform_silver.cdm.keeping_children_safe_social_care
),
GroupMin AS (
    SELECT FamilyID, MIN(NeedMet) AS MinNeedMetInGroup
    FROM WithNeedMet
    GROUP BY FamilyID
)
SELECT
    EA.FamilyID,
    EA.SchoolPersonID,
    CASE
       WHEN EA.Attendance_1_Need = 'Yes' THEN 'Pass'
       WHEN EA.Attendance_1_Need = 'No' THEN 'Fail'
       ELSE NULL
    END AS Attendance1NeedStatus,
    CASE
       WHEN EA.Attendance_1_Need_Met_Individual = 'Yes' THEN 'Pass'
       WHEN EA.Attendance_1_Need_Met_Individual = 'No' THEN 'Fail'
       ELSE NULL
    END AS Attendance1NeedMetIndividualStatus,
    CASE
       WHEN EA.Attendance_2_Need = 'Yes' THEN 'Pass'
       WHEN EA.Attendance_2_Need = 'No' THEN 'Fail'
       ELSE NULL
    END AS Attendance2NeedStatus,
    CASE
       WHEN EA.Attendance_2_Need_Met_Individual = 'Yes' THEN 'Pass'
       WHEN EA.Attendance_2_Need_Met_Individual = 'No' THEN 'Fail'
       ELSE 'N/A'
    END AS Attendance2NeedMetIndividualStatus,
    CASE
       WHEN GM.MinNeedMetInGroup IS NULL THEN NULL
       WHEN GM.MinNeedMetInGroup > 0 THEN 'Pass'
       ELSE 'Fail'
    END AS KeepingChildrenSafeCSCNeedMetFamilyStatus
FROM lh_data_platform_silver.cdm.education_attendance_needsmet_summary_detail EA
LEFT JOIN GroupMin GM
    ON EA.FamilyID = GM.FamilyID
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.vw_individual_attendance_pass_fail")


# In[33]:


# cdm.vw_individual_attendance_pass_fail_summary   <- vw_individual_attendance_pass_fail
df = spark.sql("""
SELECT
    FamilyID,
    CASE WHEN COUNT(CASE WHEN Attendance1NeedStatus = 'Fail' THEN 1 END) > 0 THEN 'Fail' ELSE 'Pass' END
        AS Family_Attendance1Need,
    CASE WHEN COUNT(CASE WHEN Attendance1NeedMetIndividualStatus = 'Fail' THEN 1 END) > 0 THEN 'Fail' ELSE 'Pass' END
        AS Family_Attendance1NeedMetIndividual,
    CASE WHEN COUNT(CASE WHEN Attendance2NeedStatus = 'Fail' THEN 1 END) > 0 THEN 'Fail' ELSE 'Pass' END
        AS Family_Attendance2Need,
    CASE WHEN COUNT(CASE WHEN Attendance2NeedMetIndividualStatus = 'Fail' THEN 1 END) > 0 THEN 'Fail' ELSE 'Pass' END
        AS Family_Attendance2NeedMetIndividual,
    CASE WHEN COUNT(CASE WHEN KeepingChildrenSafeCSCNeedMetFamilyStatus = 'Fail' THEN 1 END) > 0 THEN 'Fail' ELSE 'Pass' END
        AS KeepingChildrenSafeCSCNeedMetFamilyStatus,
    -- Overall: any individual failing any check => Fail
    CASE
        WHEN COUNT(CASE WHEN Attendance1NeedStatus = 'Fail' THEN 1 END) > 0
          OR COUNT(CASE WHEN Attendance2NeedStatus = 'Fail' THEN 1 END) > 0
          -- OR COUNT(CASE WHEN Attendance2NeedMetIndividualStatus = 'Fail' THEN 1 END) > 0
          OR COUNT(CASE WHEN KeepingChildrenSafeCSCNeedMetFamilyStatus = 'Fail' THEN 1 END) > 0
        THEN 'Fail'
        ELSE 'Pass'
    END AS FamilyStatus
FROM lh_data_platform_silver.cdm.vw_individual_attendance_pass_fail
GROUP BY FamilyID
ORDER BY FamilyID
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.vw_individual_attendance_pass_fail_summary")


# In[34]:


# cdm.vw_family_children_counts   <- vw_individual_attendance_pass_fail
df = spark.sql("""
SELECT
    FamilyID,
    COUNT(DISTINCT SchoolPersonID) AS ChildrenInFamily
FROM lh_data_platform_silver.cdm.vw_individual_attendance_pass_fail
WHERE FamilyID IS NOT NULL
GROUP BY FamilyID
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.vw_family_children_counts")


# In[35]:


# ============================================================
# STAGE 7 — Legacy "_old" tables (nothing downstream reads these).
# Safe to delete these two cells once you've confirmed they're not
# used by any report.
# ============================================================

# cdm.vw_school_term_dates_old   <- school_term_dates
df = spark.sql("""
WITH terms_cte AS (
    SELECT
        ROW_NUMBER() OVER (ORDER BY TermStartDate DESC) AS RowNum,
        CASE WHEN current_date() BETWEEN TermStartDate AND TermEndDate THEN 1 ELSE 0 END AS IsCurrent,
        CONCAT(
            substring(regexp_replace(`Year`, '[^0-9]', ''), 1, 4),
            substring(regexp_replace(`Year`, '[^0-9]', ''), 5, 2),
            '0',
            CAST(Term AS STRING)
        ) AS TermKey,
        `Year`,
        Term,
        TermStartDate,
        TermEndDate
    FROM lh_data_platform_silver.cdm.school_term_dates
),
cur AS (
    SELECT MAX(CASE WHEN IsCurrent = 1 THEN RowNum END) AS CurrentRowNum
    FROM terms_cte
)
SELECT
    t.TermKey,
    t.`Year`,
    t.Term,
    t.TermStartDate,
    t.TermEndDate,
    COALESCE(c.CurrentRowNum, 0) - t.RowNum AS RelativeTerm
FROM terms_cte t
CROSS JOIN cur c
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.vw_school_term_dates_old")


# In[36]:


# cdm.vw_attendance_old
#   <- vw_school_event, school_person, supporting_families_person,
#      supporting_families_event, vw_school_term_dates, vw_relative_term_dates
df = spark.sql("""
SELECT DISTINCT
    allTerms.UPN,
    allTerms.SchoolPersonID,
    allTerms.FamilyID,
    allTerms.GroupID,
    allTerms.TermKey,
    schoolEvent.AvailableSessions,
    schoolEvent.AuthorisedSessions,
    schoolEvent.UnauthorisedSessions,
    allTerms.RelativeTerm,
    allTerms.RelativeStartTerm,
    allTerms.RelativeEndTerm,
    allTerms.SFStartDate,
    allTerms.SFEndDate
FROM lh_data_platform_silver.cdm.vw_school_event AS schoolEvent
JOIN (
    SELECT
        terms.TermKey,
        terms.RelativeTerm,
        startTerm.RelativeStartTerm,
        endTerm.RelativeEndTerm,
        person.UPN,
        person.SchoolPersonID,
        sfEvent.FamilyID,
        sfEvent.GroupID,
        sfEvent.SFStartDate,
        sfEvent.SFEndDate
    FROM lh_data_platform_silver.cdm.school_person AS person
    JOIN lh_data_platform_silver.cdm.supporting_families_person AS sfPerson
        ON sfPerson.UPN = person.UPN
    JOIN lh_data_platform_silver.cdm.supporting_families_event AS sfEvent
        ON sfEvent.PersonID = sfPerson.PersonID
    FULL OUTER JOIN lh_data_platform_silver.cdm.vw_school_term_dates AS terms ON 1 = 1
    JOIN lh_data_platform_silver.cdm.vw_relative_term_dates AS startTerm
        ON startTerm.SchoolPersonID = person.SchoolPersonID
    JOIN lh_data_platform_silver.cdm.vw_relative_term_dates AS endTerm
        ON endTerm.SchoolPersonID = person.SchoolPersonID
    WHERE terms.RelativeTerm >= startTerm.RelativeStartTerm - 3
) allTerms
ON allTerms.UPN = schoolEvent.UPN AND allTerms.TermKey = schoolEvent.TermKey
""")

OverwriteLoad(df, "lh_data_platform_silver.cdm.vw_attendance_old")


# In[37]:


# ============================================================
# STAGE 8 — Validation: row counts for everything built this run
# ============================================================

summary = [(t, spark.table(t).count()) for t in BUILT_TABLES]
summary_df = spark.createDataFrame(summary, ["table_name", "row_count"])
display(summary_df)

empty = [t for t, n in summary if n == 0]
if empty:
    print("WARNING — built but empty:")
    for t in empty:
        print(f"  {t}")
else:
    print(f"All {len(summary)} tables built with rows.")


# In[38]:


# TermKey alignment check: school events vs term dates (should be > 0)
spark.sql("""
SELECT COUNT(*) AS match_termkey_only
FROM (SELECT DISTINCT CAST(TermKey AS STRING) AS TermKey
      FROM lh_data_platform_silver.cdm.vw_school_event WHERE TermKey IS NOT NULL) e
JOIN (SELECT DISTINCT CAST(TermKey AS STRING) AS TermKey
      FROM lh_data_platform_silver.cdm.vw_school_term_dates WHERE TermKey IS NOT NULL) t
  ON e.TermKey = t.TermKey
""").show()
