# Lloyds Living — Data Domain Model
*Draft for customer workshop review · built from the profiled FixFlo / SLM / QUBE schema (23-07-2026) and the Data Model Workshop pack (v0.1)*

This groups the tables profiled so far into data domains, shows how they're
candidate-linked, and gives a starting set of Silver and Gold SQL views for
each domain. It's a discussion aid — every join below is inferred from
field-name matching, not validated against live data, exactly as flagged in
the workshop pack.

---

## 1. Conceptual domain map

```mermaid
flowchart TB

    subgraph HIER["FixFlo property hierarchy (non-prod export)"]
        direction TB
        ESTATE["Estate"]
        BLOCK["Block"]
        FFPROP["FixFlo Property"]
        ESTATE --> BLOCK --> FFPROP
    end

    subgraph PROP["PROPERTY domain"]
        direction TB
        SLMPROP["SLM Property\n(core attributes)"]
        QUBEPROP["QUBE Property"]
        ADDR["Address"]
        ENERGY["Energy Rating"]
        CUSTF["Custom Fields"]
        LIFE["Lifestyle"]
        MEDIA["Media"]
        METER["Meter Readings"]
        SLMPROP --- ADDR
        SLMPROP --- ENERGY
        SLMPROP --- CUSTF
        SLMPROP --- LIFE
        SLMPROP --- MEDIA
        SLMPROP --- METER
        SLMPROP -. "candidate: qube_reference = reference" .-> QUBEPROP
    end

    subgraph PARTY["PERSON / PARTY domain"]
        direction TB
        PERSON["Person"]
        POWNER["Property Owner (bridge)"]
        PROLE["Property-Person Role (bridge)"]
        PERSON --- POWNER
        PERSON --- PROLE
    end

    subgraph LAND["LANDLORD domain"]
        LANDLORD["Landlord\n(fix_flo property-landlords export)"]
    end

    subgraph OCC["TENANT / OCCUPIER domain\n(no dedicated master source)"]
        OCCUPIER["Occupier fields\n(embedded on Issue)"]
        TENANT["Tenant fields\n(embedded on Complaint)"]
    end

    subgraph CONTR["CONTRACTOR domain\n(no dedicated master source)"]
        CONTRACTOR["Contractor fields\n(embedded on 4 tables)"]
    end

    subgraph SVC["SERVICE / MAINTENANCE domain"]
        direction TB
        SERVEVT["Service Event\n(planned/reactive instruction)"]
        LASTCOMP["Last Completed Event\n(cadence + last-run status)"]
    end

    subgraph COMP["COMPLIANCE / CERTIFICATE domain"]
        CERT["Completed Event + Certificate"]
    end

    subgraph REPAIR["REPAIRS / ISSUES domain"]
        direction TB
        ISSUE["Issue"]
        FEEDBACK["Customer Feedback"]
        ISSUE -. "candidate: Issue_ID = issue_Id" .-> FEEDBACK
    end

    subgraph CMPL["COMPLAINTS domain"]
        COMPLAINT["Tenant Complaint"]
    end

    subgraph INV["INVOICE / FINANCIAL domain\n(not yet profiled - gap)"]
        NOINV["No source table seen.\nClosest proxy: cost fields\non Issue (Payable / Receivable Gross)"]
    end

    FFPROP -. "candidate: ExternalPropertyRef" .-> LANDLORD
    FFPROP -. "candidate: Fixflo_Unit_Property_ID" .-> SERVEVT
    FFPROP -. "candidate: Unit_Property_ID" .-> LASTCOMP
    FFPROP -. "candidate: External_Unit_Ref" .-> ISSUE
    FFPROP -. "candidate: Property_Ref" .-> COMPLAINT
    SERVEVT -. "candidate: Latest_Issue_Id" .-> ISSUE
    SERVEVT -. "candidate: Reference_Id" .-> LASTCOMP
    ISSUE -. "candidate: Service_Event_Reference_ID" .-> CERT
    SLMPROP <-. "master property key: open question" .-> FFPROP

    style INV fill:#fde2e2,stroke:#c0392b,stroke-dasharray: 5 5
    style OCC fill:#fff3cd,stroke:#b8860b,stroke-dasharray: 5 5
    style CONTR fill:#fff3cd,stroke:#b8860b,stroke-dasharray: 5 5
```

*(also saved standalone as `01_Domain_Map.mermaid`)*

## 2. Detailed logical ERD

```mermaid
erDiagram

    ESTATE {
        string EstateId PK
        string ExternalEstateRef
        string EstateName
    }
    BLOCK {
        string BlockId PK
        string EstateId FK
        string ExternalBlockRef
        string BlockName
        string BlockPropertyManager
    }
    FIXFLO_PROPERTY {
        string PropertyId PK
        string BlockId FK
        string ExternalPropertyRef
        string KeyReference
        string PropertyManager
        string PropertyIsManaged
    }
    LANDLORD_EXPORT {
        string PropertyId PK
        string ExternalPropertyRef
        string ExternalLandlordRef
        string LandlordDisplayName
        string LandlordEmailAddress
        string PropertyManager
    }

    SLM_PROPERTY {
        string property_hk PK
        string property_id
        string qube_reference
        float uprn
        string property_type
        string status
        string branch
        string management_type
    }
    QUBE_PROPERTY {
        string property_hk PK
        bigint id
        string reference
        string postcode
        string tenure
        string type
    }
    ADDRESS {
        string property_hk FK
        string property_id
        string uprn
        string location
    }
    ENERGY_RATING {
        string property_hk FK
        string energy_rating_current
        string energy_rating_potential
        string environmental_impact_current
        string environmental_impact_potential
    }
    CUSTOM_FIELD {
        string property_custom_field_hk PK
        string property_hk FK
        string field_title
        string field_type
        string field_value
    }
    LIFESTYLE {
        string property_lifestyle_hk PK
        string property_hk FK
        int lifestyle_sequence_number
        string item_json
    }
    MEDIA {
        string property_media_hk PK
        string property_hk FK
        string caption
        int media_type
        string media_url
    }
    METER_READING {
        string property_meter_reading_hk PK
        string property_hk FK
        int meter_reading_sequence_number
        string item_json
    }
    PERSON {
        string person_hk PK
        string source_person_id
        string person_name
    }
    PROPERTY_OWNER {
        string property_owner_hk PK
        string property_hk FK
        string person_id FK
        string owner_role_code
        string contract_id
    }
    PROPERTY_PERSON_ROLE {
        string property_person_role_hk PK
        string property_hk FK
        string person_hk FK
        string role_code
        string role_name
    }

    SERVICE_EVENT {
        string Reference_Id PK
        string Fixflo_Unit_Property_ID FK
        string Latest_Issue_Id FK
        string Contractor_Company_Name
        string Due_Date
        string Service_Event_Status
    }
    LAST_COMPLETED_EVENT {
        string Service_Event_ID PK
        string Unit_Property_ID FK
        string Block_ID FK
        string Completed_Status
        string Contractor_Company_Name
        string Planned_Maintenance_Event_Frequency
    }
    COMPLETED_EVENT_CERTIFICATE {
        string Service_Event_Reference_ID FK
        string Unit_Reference
        string Certificate_Media_File
        string Due_Date
        string Completed_Date
    }
    ISSUE {
        string Issue_ID PK
        string External_Unit_Ref FK
        string Service_Event_Id FK
        string Contractor_Id
        string Fault_Category
        string Issue_Status
        string Price_Agency_Payable_Gross
        string Price_Agency_Receivable_Gross
    }
    CUSTOMER_FEEDBACK {
        string issue_Id PK
        string Contractor_Id
        string Repair_Rating
        string Occupier_Contractor_Rating
    }
    TENANT_COMPLAINT {
        string Reference_Number PK
        string Property_Ref FK
        string Tenant_Ref
        string Complaint_Category
        string MI___Complaint_Status
    }

    ESTATE ||--o{ BLOCK : has
    BLOCK ||--o{ FIXFLO_PROPERTY : has
    FIXFLO_PROPERTY ||--o{ LANDLORD_EXPORT : "candidate ExternalPropertyRef"
    SLM_PROPERTY ||--o| QUBE_PROPERTY : "candidate qube_reference=reference"
    SLM_PROPERTY ||--o{ ADDRESS : has
    SLM_PROPERTY ||--o{ ENERGY_RATING : has
    SLM_PROPERTY ||--o{ CUSTOM_FIELD : has
    SLM_PROPERTY ||--o{ LIFESTYLE : has
    SLM_PROPERTY ||--o{ MEDIA : has
    SLM_PROPERTY ||--o{ METER_READING : has
    SLM_PROPERTY ||--o{ PROPERTY_OWNER : has
    PROPERTY_OWNER }o--|| PERSON : "via person_id"
    SLM_PROPERTY ||--o{ PROPERTY_PERSON_ROLE : has
    PROPERTY_PERSON_ROLE }o--|| PERSON : "via person_hk"
    FIXFLO_PROPERTY ||--o{ SERVICE_EVENT : "candidate Fixflo_Unit_Property_ID"
    FIXFLO_PROPERTY ||--o{ LAST_COMPLETED_EVENT : "candidate Unit_Property_ID"
    FIXFLO_PROPERTY ||--o{ ISSUE : "candidate External_Unit_Ref"
    FIXFLO_PROPERTY ||--o{ TENANT_COMPLAINT : "candidate Property_Ref"
    SERVICE_EVENT |o--o| ISSUE : "candidate Latest_Issue_Id"
    SERVICE_EVENT ||--o{ LAST_COMPLETED_EVENT : "candidate Reference_Id"
    ISSUE ||--o{ COMPLETED_EVENT_CERTIFICATE : "candidate Service_Event_Reference_ID"
    ISSUE ||--o| CUSTOMER_FEEDBACK : "candidate Issue_ID=issue_Id"
    SLM_PROPERTY }o..o{ FIXFLO_PROPERTY : "master property key: open question"
```

*(also saved standalone as `02_Detailed_ERD.mermaid`)*

---

## 3. Domain summary

| Domain | Source table(s) | Grain | Status |
|---|---|---|---|
| **Property** | SLM.property, QUBE.property, fix_flo-property_import | one row per property (per source) | 3 systems, no confirmed conformed key |
| **Property attributes** | property_address, property_energy_rating, property_custom_field, property_lifestyle, property_media, property_meter_reading | one row per attribute per property | satellite tables off SLM.property_hk |
| **Person / Party** | SLM.person, property_owner, property_person_role | one row per person / per role | role-based many-to-many, clean hub |
| **Landlord** | fix_flo-all_property_landlords_export | one row per property+landlord (denormalised) | needs splitting into landlord dim + link |
| **Tenant / Occupier** | embedded in Issue, Tenant Complaint | no dedicated master | **gap** — open question in workshop pack |
| **Contractor** | embedded in Issue, Feedback, Service Event, Last Completed Event | no dedicated master, inconsistent shape | **gap** — Contractor_Id only on 2 of 4 sources |
| **Service / Maintenance** | fix_flo-all_service_events, fix_flo-last_completed_events | one row per instruction / per last-run snapshot | fix_flo (non-prod) only — no prod equivalent |
| **Compliance / Certificate** | cleaned.fix_flo-all_completed_events_with_certificates | one row per completed event | cleaned schema treated as authoritative |
| **Repairs / Issues** | fix_flo-all_issues_report | one row per issue | widest table; carries the only cost data |
| **Feedback** | fix_flo-customer_feedback | one row per feedback response | links to Issue via issue id |
| **Complaints** | fix_flo-tenant_complaints | one row per complaint | fix_flo (non-prod) only — no prod equivalent |
| **Energy Rating** | SLM.property_energy_rating | one row per property | EPC-style; current values only, no history seen |
| **Invoice / Financial** | *none profiled* | — | **gap** — nearest proxy is cost fields on Issue |

---

## 4. Carried-forward open questions (from the workshop pack)

These aren't resolved by the newer ERD profiling and are worth re-confirming
in the review:

1. **Master property key** — is there a shared key across FixFlo/SLM/QUBE
   today (UPRN, external reference, address+postcode), or does one need to
   be agreed as part of this engagement?
2. **fix_flo_prod vs fix_flo (non-prod)** — Estate/Block hierarchy, Tenant
   Complaints and Service Events currently only exist in non-prod. Add to
   prod, keep sourcing from non-prod ongoing, or leave out of scope?
3. **Contractor business key** — Contractor_Id appears on Issues/Feedback
   only; Service Events/Completed Events carry name/email instead. What's
   the conformed key?
4. **Occupier/Tenant master** — is a proper tenant master expected to exist
   elsewhere, or is embedded-per-issue the only source?
5. **Invoice / financial data** — no billing or ledger source has been
   profiled at all. Is this genuinely out of scope, or is there a system
   (e.g. QUBE) that hasn't been profiled yet?
6. **SLM/QUBE grain** — is each SLM.property ingest a full snapshot or
   change-only? Affects whether Silver needs SCD handling.

---

## 5. SQL views

Two scripts are provided, organised by the same domains as above:

- **`03_silver_views.sql`** — one conformed view per raw source table
  (renamed/cast, drift standardised), plus a couple of joined-up "360" views
  to demo relationships.
- **`04_gold_views.sql`** — a draft star schema: `dim_property`, `dim_estate`,
  `dim_block`, `dim_address`, `dim_energy_rating`, `dim_person`,
  `dim_landlord`, `dim_contractor`, `dim_tenant`, bridge tables for the
  property↔person many-to-many, and facts for issues, service events,
  completed events/certificates, complaints and feedback — plus a thin
  `fact_issue_cost` view standing in for the missing invoice domain.

Every "candidate" join from the ERD is carried into the SQL as a commented
`-- CANDIDATE JOIN (unconfirmed)` so nothing reads as more certain than it
is — worth keeping that framing when walking the customer through it.
