/* ============================================================================
   LLOYDS LIVING — SILVER LAKEHOUSE VIEWS
   ============================================================================
   Purpose : Conformed, cleansed views over the raw FixFlo / SLM / QUBE tables
             profiled in "LL - Silver - ERD draft v1.0" (23-07-2026), organised
             into data domains, for review with the customer and as a starting
             point for the real Fabric build.

   Status  : DRAFT / DISCUSSION AID. Every join marked "CANDIDATE" is inferred
             from field-name matching only (per the workshop pack) and has
             NOT been validated against live key values. Do not promote this
             to production without validating cardinality and key population.

   Assumptions made to write runnable T-SQL:
     - Written for the Fabric Warehouse / SQL analytics endpoint T-SQL surface.
       If Silver is actually being built as Spark SQL notebooks against the
       Lakehouse, the SELECT logic ports directly — swap CREATE OR ALTER VIEW
       for CREATE OR REPLACE VIEW and TRY_CONVERT(date, x, 103) for
       to_date(x,'dd/MM/yyyy').
     - All raw tables assumed reachable via three-part names
       [schema].[table] in one Warehouse/Lakehouse; adjust to
       [LakehouseName].[schema].[table] if Silver and raw sit in separate
       Fabric items.
     - Date-like varchar(8000) columns are cast assuming UK dd/mm/yyyy
       (style 103). Unconfirmed — validate against real values before relying
       on these casts.
     - cleaned.fix_flo-all_completed_events_with_certificates is treated as
       the authoritative source (it already looks like an in-flight Silver
       output); the fix_flo. raw twin is not rebuilt separately.
     - fix_flo (non-prod) tables are used throughout because that's what's
       been profiled in the ERD. Per the workshop pack, fix_flo_prod is the
       intended schema of record for FixFlo reporting — swap the source
       schema once prod is profiled and the same shape confirmed.
     - Contractor and Occupier/Tenant have no dedicated master source today
       (open questions in the workshop pack). The silver.contractor and
       silver.occupier views below are provisional, built by pooling the
       embedded fields — treat their business keys as placeholders.
   ============================================================================ */

-- ============================================================================
-- DOMAIN: PROPERTY
-- ============================================================================

-- SLM.property — core property attributes (lettings/management system)
CREATE OR ALTER VIEW silver.property AS
SELECT
    property_hk,
    property_id,
    qube_reference,
    uprn,
    property_type,
    property_type_code,
    status,
    status_code,
    available,
    branch,
    branch_code,
    property_manager_site,
    property_manager_site_code,
    management_type,
    setting,
    style,
    style_code,
    floor,
    garden,
    council_tax,
    hmo,
    hmo_license_no,
    mandatory_licensing,
    selective_licensing,
    selective_licensing_no,
    additional_licensing,
    unlicensed,
    registration,
    minimum_term,
    minimum_term_period,
    periodic,
    first_rent_weeks,
    valuation,
    exchange,
    exclusivity_expiry,
    internet_advertising,
    maintenance_instructions,
    no_of_house_holds,
    department,
    display_address,
    age,
    ndo,
    completion,
    TRY_CONVERT(date, create_date, 103)     AS create_date,
    TRY_CONVERT(date, update_date, 103)     AS update_date,
    TRY_CONVERT(date, start_date, 103)      AS start_date,
    TRY_CONVERT(date, end_date, 103)        AS end_date,
    TRY_CONVERT(date, completed_date, 103)  AS completed_date,
    TRY_CONVERT(date, market_date, 103)     AS market_date,
    TRY_CONVERT(date, date_available, 103)  AS date_available,
    TRY_CONVERT(date, archived_date, 103)   AS archived_date
FROM SLM.property;
GO

-- QUBE.property — legacy/lettings property system, candidate link to SLM via reference
CREATE OR ALTER VIEW silver.property_qube AS
SELECT
    property_hk,
    id                AS qube_property_id,
    reference         AS qube_reference,
    address1, address2, address3, address4, address5, address6,
    area_code,
    postcode,
    description,
    status,
    tenure,
    type
FROM QUBE.property;
GO

-- fix_flo property_import — the only source carrying Estate > Block > Property
CREATE OR ALTER VIEW silver.property_fixflo_hierarchy AS
SELECT
    EstateId,
    ExternalEstateRef,
    EstateName,
    EstateTags,
    BlockId,
    ExternalBlockRef,
    BlockName,
    BlockPropertyManager,
    BlockAddressLine1, BlockAddressLine2, BlockTown, BlockCounty, BlockPostCode,
    BlockTags,
    PropertyId,
    ExternalPropertyRef,
    KeyReference,
    PropertyTags,
    PropertyRelationship,
    PropertyManager,
    PropertyIsManaged,
    PropertyBrand,
    PropertyAddressLine1, PropertyAddressLine2, PropertyTown, PropertyCounty, PropertyPostCode,
    PropertyAssignedAgent,
    PropertyAssignedTeam,
    IsPropertyDeactivated,
    _meta_pipeline_id,
    _meta_ingest_ts
FROM fix_flo.[fix_flo-property_import];
GO

CREATE OR ALTER VIEW silver.property_address AS
SELECT
    property_hk,
    property_id,
    qube_reference,
    uprn,
    location
FROM SLM.property_address;
GO

CREATE OR ALTER VIEW silver.property_energy_rating AS
SELECT
    property_hk,
    property_id,
    qube_reference,
    uprn,
    energy_rating_current,
    energy_rating_potential,
    environmental_impact_current,
    environmental_impact_potential
FROM SLM.property_energy_rating;
GO

CREATE OR ALTER VIEW silver.property_custom_field AS
SELECT
    property_custom_field_hk,
    property_hk,
    property_id,
    qube_reference,
    uprn,
    custom_field_sequence_number,
    field_code,
    field_title,
    field_type,
    field_value
FROM SLM.property_custom_field;
GO

CREATE OR ALTER VIEW silver.property_lifestyle AS
SELECT
    property_lifestyle_hk,
    property_hk,
    property_id,
    qube_reference,
    uprn,
    lifestyle_sequence_number,
    item_json AS lifestyle_json
FROM SLM.property_lifestyle;
GO

CREATE OR ALTER VIEW silver.property_media AS
SELECT
    property_media_hk,
    property_hk,
    property_id,
    qube_reference,
    uprn,
    media_sequence_number,
    caption,
    media_type,
    media_url,
    sort_order
FROM SLM.property_media;
GO

CREATE OR ALTER VIEW silver.property_meter_reading AS
SELECT
    property_meter_reading_hk,
    property_hk,
    property_id,
    qube_reference,
    uprn,
    meter_reading_sequence_number,
    item_json AS meter_reading_json
FROM SLM.property_meter_reading;
GO

-- Consolidated "single property" view — property + qube link + address + energy rating.
-- Good candidate for the first thing to demo back to the customer.
CREATE OR ALTER VIEW silver.vw_property_360 AS
SELECT
    p.property_hk,
    p.property_id,
    p.qube_reference,
    p.uprn,
    p.property_type,
    p.status,
    p.branch,
    p.management_type,
    a.location                                  AS address_location,
    q.address1, q.address2, q.postcode           AS qube_postcode,
    e.energy_rating_current,
    e.energy_rating_potential,
    e.environmental_impact_current
FROM silver.property AS p
LEFT JOIN silver.property_address AS a
    ON a.property_hk = p.property_hk
LEFT JOIN silver.property_qube AS q                       -- CANDIDATE JOIN (unconfirmed)
    ON q.qube_reference = p.qube_reference
LEFT JOIN silver.property_energy_rating AS e
    ON e.property_hk = p.property_hk;
GO

-- ============================================================================
-- DOMAIN: ADDRESS
-- ============================================================================
-- No standalone conformed address master exists today — addresses are embedded
-- per-source (SLM.property_address, QUBE.property, FixFlo property/landlord
-- exports). silver.property_address above is the closest thing to a dedicated
-- address entity; Gold's dim_address pools from all of these (see Gold script).

-- ============================================================================
-- DOMAIN: PERSON / PARTY
-- ============================================================================

CREATE OR ALTER VIEW silver.person AS
SELECT
    person_hk,
    source_person_id,
    person_name
FROM SLM.person;
GO

CREATE OR ALTER VIEW silver.property_owner AS
SELECT
    property_owner_hk,
    property_hk,
    property_id,
    qube_reference,
    uprn,
    owner_sequence_number,
    owner_id,
    owner_link,
    person_id,
    owner_role_code,
    contract_id
FROM SLM.property_owner;
GO

CREATE OR ALTER VIEW silver.property_person_role AS
SELECT
    property_person_role_hk,
    property_hk,
    property_id,
    qube_reference,
    uprn,
    person_hk,
    source_person_id,
    person_name,
    role_code,
    role_name
FROM SLM.property_person_role;
GO

-- ============================================================================
-- DOMAIN: LANDLORD
-- ============================================================================
-- fix_flo-all_property_landlords_export is a denormalised property+landlord
-- row. Split it into a landlord-grain view and a property-link view.

CREATE OR ALTER VIEW silver.landlord AS
SELECT DISTINCT
    ExternalLandlordRef,
    LandlordUserTypeId,
    LandlordTitle,
    LandlordFirstName,
    LandlordSurname,
    LandlordCompanyName,
    LandlordDisplayName,
    LandlordEmailAddress,
    LandlordEmailCC,
    LandlordTel1,
    LandlordTel2,
    LandlordAddressLine1,
    LandlordAddressLine2,
    LandlordTown,
    LandlordCounty,
    LandlordPostCode,
    LandlordBrandId,
    LandlordIsDeleted,
    TRY_CONVERT(date, LandlordDateFrom, 103) AS landlord_date_from,
    TRY_CONVERT(date, LandlordDateTo, 103)   AS landlord_date_to
FROM fix_flo.[fix_flo-all_property_landlords_export];
GO

CREATE OR ALTER VIEW silver.property_landlord_link AS
SELECT
    PropertyId,
    ExternalPropertyRef,
    ExternalLandlordRef,
    PropertyAssignedAgent,
    PropertyAssignedTeam,
    PropertyManager,
    PropertyIsDeactivated,
    LandlordAssignedAgent,
    LandlordAssignedTeam,
    Tags,
    _meta_pipeline_id,
    _meta_ingest_ts
FROM fix_flo.[fix_flo-all_property_landlords_export];
GO

-- ============================================================================
-- DOMAIN: SERVICE / MAINTENANCE
-- ============================================================================

CREATE OR ALTER VIEW silver.service_event AS
SELECT
    Reference_Id,
    Fixflo_Unit_Property_ID,
    Latest_Issue_Id,
    Programme_Name,
    Assigned_Agent,
    External_Building_Ref,
    Building_Name,
    Estate_Name,
    Unit_Address_Line_1, Unit_Address_Line_2, Unit_Postcode, Unit_Ext_Ref,
    Contractor_Company_Name,
    Contractor_Firstname,
    Contractor_Surname,
    Instruction_Notes,
    Is_Deactivated,
    Instruction_Date_Offset_Period,
    Offset_Time_Period,
    Requires_Review,
    Reviewer_Name,
    Cost_Code,
    Service_Frequency,
    Frequency_Period,
    Service_Event_Status,
    TRY_CONVERT(date, Updated, 103)          AS updated_date,
    TRY_CONVERT(date, Due_Date, 103)         AS due_date,
    TRY_CONVERT(date, Instruction_Date, 103) AS instruction_date,
    TRY_CONVERT(date, Completion_Date, 103)  AS completion_date
FROM fix_flo.[fix_flo-all_service_events];
GO

CREATE OR ALTER VIEW silver.last_completed_event AS
SELECT
    Service_Event_ID,
    Unit_Property_ID,
    Unit_Property_Ext_Ref,
    Block_ID,
    Block_Ext_Ref,
    Planned_Maintenance_Event_Template,
    Planned_Maintenance_Event_Frequency,
    Planned_Maintenance_Event_Frequency_Type,
    Planned_Maintenance_Instruction_Date_Offset_Period,
    Planned_Maintenance_Instruction_Date_Offset_Type,
    Planned_Maintenance_Event_Agent_Assignee,
    Planned_Maintenance_Event_Reviewer,
    Completed_Status,
    Planned_Maintenance_Event_Requires_Review,
    Contractor_First_Name,
    Contractor_Surname,
    Contractor_Company_Name,
    Contractor_Email_Address,
    External_Contractor_Ref,
    Cost_Code,
    Landlord,
    Is_Deactivated,
    TRY_CONVERT(date, Planned_Maintenance_Event_Last_Completed_Date, 103) AS last_completed_date,
    TRY_CONVERT(date, Planned_Maintenance_Event_Start_Date, 103)          AS start_date,
    TRY_CONVERT(date, Planned_Maintenance_Event_End_Date, 103)            AS end_date
FROM fix_flo.[fix_flo-last_completed_events];
GO

-- ============================================================================
-- DOMAIN: COMPLIANCE / CERTIFICATE
-- ============================================================================
-- Preferring the "cleaned" schema copy — it already looks like an in-flight
-- Silver output for this one table.

CREATE OR ALTER VIEW silver.completed_event_certificate AS
SELECT
    Service_Event_Reference_ID,
    Service_Event_Programme_Name,
    Unit_Reference,
    Certificate_Media_File,
    TRY_CONVERT(date, Due_Date, 103)        AS due_date,
    TRY_CONVERT(date, Instruction_Date, 103) AS instruction_date,
    TRY_CONVERT(date, Completed_Date, 103)   AS completed_date
FROM cleaned.[fix_flo-all_completed_events_with_certificates];
GO

-- ============================================================================
-- DOMAIN: REPAIRS / ISSUES
-- ============================================================================

CREATE OR ALTER VIEW silver.issue AS
SELECT
    Issue_ID,
    External_Ref_Job,
    External_Unit_Ref,
    External_Estate_Ref,
    External_Block_Ref,
    Service_Event_Id,
    Service_Event_Reference,
    Fault_Priority,
    Issue_Title,
    Fault_Category,
    Fault_Notes,
    Estate_Name,
    Building_PM,
    Site_Name,
    Issue_Address,
    Close_Reason,
    Close_Reason_Desc,
    Issue_Status,
    Ext_User, Ext_User_Email,
    Assigned_Team, Assigned_Agent,
    Unit_Manager_display_Name,
    Occupier_display_Name,
    Occupier_email_Address,
    Occupier_contact_No, Occupier_contact_No_Alt,
    Occupier_Address_Line_1, Occupier_Address_Line_2, Occupier_town, Occupier_post_Code,
    Raised_By_User_Id, Raised_By_User_Type,
    Contractor_Id,
    Contractor_Company_Name,
    Contractor_Firstname,
    Contractor_Surname,
    Cost_Code,
    TRY_CONVERT(date, Issue_Created, 103)          AS issue_created_date,
    TRY_CONVERT(date, Quote_End_Date, 103)         AS quote_end_date,
    TRY_CONVERT(date, Job_Start_Date, 103)          AS job_start_date,
    TRY_CONVERT(date, Job_Completed, 103)           AS job_completed_date,
    TRY_CONVERT(date, Closed_Date, 103)             AS closed_date,
    TRY_CONVERT(date, Issue_Status_Changed, 103)    AS issue_status_changed_date,
    TRY_CONVERT(date, Latest_Quote_Submitted_Date, 103) AS latest_quote_submitted_date,
    TRY_CAST(Days_to_close AS int)                          AS days_to_close,
    TRY_CAST(Price_Agency_Payable_Gross AS decimal(18,2))   AS price_agency_payable_gross,
    TRY_CAST(Price_Agency_Receivable_Gross AS decimal(18,2)) AS price_agency_receivable_gross,
    TRY_CAST(Works_Authorisation_Limit AS decimal(18,2))    AS works_authorisation_limit
FROM fix_flo.[fix_flo-all_issues_report];
GO

CREATE OR ALTER VIEW silver.customer_feedback AS
SELECT
    issue_Id,
    Address_Summary,
    Customer_Accept_Complete,
    Contractor_Id,
    Contractor_Name,
    Occupier_Contractor_Rating,
    Occupier_Notes,
    Assigned_Agent,
    Assigned_Agent_Id,
    Repair_Acknowledged_Promptly,
    Repair_Rating,
    Job_Completed
FROM fix_flo.[fix_flo-customer_feedback];
GO

-- ============================================================================
-- DOMAIN: COMPLAINTS
-- ============================================================================

CREATE OR ALTER VIEW silver.tenant_complaint AS
SELECT
    Reference_Number,
    Tenant_Ref,
    Tenant_Name,
    [UNit_Ref]           AS unit_ref,
    To_unit_Desc,
    Property_Ref,
    Property_Desc,
    Owner,
    Complaint_Category,
    Description_of_Complaint,
    [MI___Complaint_Status] AS complaint_status,
    TRY_CONVERT(date, Date_of_Complaint, 103)                       AS date_of_complaint,
    TRY_CONVERT(date, Complaint_Acknowledged_on, 103)                AS complaint_acknowledged_on,
    TRY_CONVERT(date, [S1___Complaint_Responded_to_on], 103)         AS complaint_responded_to_on,
    TRY_CONVERT(date, [S2___Escalation_Rec_d_by_Customer_on], 103)   AS escalation_received_on,
    TRY_CONVERT(date, [S2___Acknowledgement_of_Escalation_Sent_Date], 103) AS escalation_ack_sent_on
FROM fix_flo.[fix_flo-tenant_complaints];
GO

-- ============================================================================
-- DOMAIN: CONTRACTOR (provisional — no dedicated master source, see header notes)
-- ============================================================================

CREATE OR ALTER VIEW silver.contractor AS
SELECT DISTINCT
    Contractor_Id                                                AS contractor_id,
    NULL                                                         AS contractor_company_name,
    Contractor_Firstname                                          AS contractor_first_name,
    Contractor_Surname                                            AS contractor_surname
FROM fix_flo.[fix_flo-all_issues_report]
WHERE Contractor_Id IS NOT NULL

UNION

SELECT DISTINCT
    NULL, Contractor_Company_Name, Contractor_Firstname, Contractor_Surname
FROM fix_flo.[fix_flo-all_service_events]
WHERE Contractor_Company_Name IS NOT NULL

UNION

SELECT DISTINCT
    NULL, Contractor_Company_Name, Contractor_First_Name, Contractor_Surname
FROM fix_flo.[fix_flo-last_completed_events]
WHERE Contractor_Company_Name IS NOT NULL;
GO
-- NOTE: this pools three different contractor "shapes" with no common key
-- (see workshop pack open question on Contractor_Id inconsistency). Treat as
-- a draft attribute pool, not a deduplicated dimension, until a conformed
-- contractor business key is agreed with the customer.

-- ============================================================================
-- DOMAIN: TENANT / OCCUPIER (provisional — no dedicated master source)
-- ============================================================================

CREATE OR ALTER VIEW silver.occupier AS
SELECT DISTINCT
    Occupier_display_Name  AS occupier_name,
    Occupier_email_Address AS occupier_email,
    Occupier_contact_No    AS occupier_phone,
    Occupier_Address_Line_1, Occupier_Address_Line_2, Occupier_town, Occupier_post_Code
FROM fix_flo.[fix_flo-all_issues_report]
WHERE Occupier_display_Name IS NOT NULL

UNION

SELECT DISTINCT
    Tenant_Name, NULL, NULL, NULL, NULL, NULL, NULL
FROM fix_flo.[fix_flo-tenant_complaints]
WHERE Tenant_Name IS NOT NULL;
GO
