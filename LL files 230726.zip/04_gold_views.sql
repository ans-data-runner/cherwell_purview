/* ============================================================================
   LLOYDS LIVING — GOLD WAREHOUSE VIEWS (draft star schema)
   ============================================================================
   Purpose : Dimension and fact views over the silver.* views, organised by
             data domain, to demo what a joined-up reporting model could look
             like. This is a discussion/prototyping aid, not a finished build.

   Conventions used:
     - Surrogate keys are generated with HASHBYTES('SHA2_256', business_key)
       cast to BIGINT. This is a common Fabric Warehouse pattern (no IDENTITY
       in views) — swap for a proper key-generation pipeline once the
       conformed business keys are agreed with the customer.
     - Every dimension carries its source business key(s) alongside the
       surrogate key so lineage back to silver/raw is traceable.
     - Anything commented "CANDIDATE" or "PROVISIONAL" mirrors the same
       caveats as the Silver script and the workshop pack — validate before
       relying on it.
     - Depends on 03_silver_views.sql being deployed first.
   ============================================================================ */

-- ============================================================================
-- DIM_DATE
-- ============================================================================
CREATE OR ALTER VIEW gold.dim_date AS
WITH seq AS (
    SELECT TOP (18262) -- ~50 years
        CAST(DATEADD(DAY, ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1, '2015-01-01') AS date) AS date_value
    FROM sys.all_objects AS a
    CROSS JOIN sys.all_objects AS b
)
SELECT
    CONVERT(int, FORMAT(date_value, 'yyyyMMdd'))  AS date_key,
    date_value,
    YEAR(date_value)                              AS calendar_year,
    DATEPART(QUARTER, date_value)                 AS calendar_quarter,
    MONTH(date_value)                             AS calendar_month,
    DATENAME(MONTH, date_value)                   AS month_name,
    DAY(date_value)                               AS day_of_month,
    DATENAME(WEEKDAY, date_value)                 AS day_name,
    CASE WHEN DATEPART(WEEKDAY, date_value) IN (1,7) THEN 1 ELSE 0 END AS is_weekend
FROM seq;
GO

-- ============================================================================
-- DOMAIN: PROPERTY
-- ============================================================================

CREATE OR ALTER VIEW gold.dim_estate AS
SELECT DISTINCT
    CAST(HASHBYTES('SHA2_256', CONCAT_WS('|', EstateId, ExternalEstateRef)) AS BIGINT) AS estate_key,
    EstateId,
    ExternalEstateRef,
    EstateName,
    EstateTags
FROM silver.property_fixflo_hierarchy;
GO

CREATE OR ALTER VIEW gold.dim_block AS
SELECT DISTINCT
    CAST(HASHBYTES('SHA2_256', CONCAT_WS('|', h.BlockId, h.ExternalBlockRef)) AS BIGINT)  AS block_key,
    CAST(HASHBYTES('SHA2_256', CONCAT_WS('|', h.EstateId, h.ExternalEstateRef)) AS BIGINT) AS estate_key,
    h.BlockId,
    h.ExternalBlockRef,
    h.BlockName,
    h.BlockPropertyManager,
    h.BlockAddressLine1, h.BlockAddressLine2, h.BlockTown, h.BlockCounty, h.BlockPostCode
FROM silver.property_fixflo_hierarchy AS h;
GO

-- dim_property — conformed property dimension. Grain: one row per property as
-- landed in SLM. FixFlo and QUBE property records are linked in as candidate
-- attributes rather than driving the grain, since the master property key
-- across all three systems is an open question (workshop pack section 6.3 /
-- open question 2) — revisit this once that's agreed.
CREATE OR ALTER VIEW gold.dim_property AS
SELECT
    CAST(HASHBYTES('SHA2_256', p.property_hk) AS BIGINT) AS property_key,
    p.property_hk,
    p.property_id,
    p.qube_reference,
    p.uprn,
    p.property_type,
    p.status,
    p.branch,
    p.management_type,
    p.setting,
    p.style,
    p.council_tax,
    p.hmo,
    p.no_of_house_holds,
    p.start_date,
    p.end_date,
    -- FixFlo-side attributes, CANDIDATE join via qube_reference/property_id — unconfirmed
    h.PropertyId          AS fixflo_property_id,
    h.ExternalPropertyRef AS fixflo_external_property_ref,
    h.PropertyManager     AS fixflo_property_manager,
    CAST(HASHBYTES('SHA2_256', CONCAT_WS('|', h.BlockId, h.ExternalBlockRef)) AS BIGINT) AS block_key
FROM silver.property AS p
LEFT JOIN silver.property_fixflo_hierarchy AS h                 -- CANDIDATE JOIN (unconfirmed)
    ON h.ExternalPropertyRef = p.qube_reference;
GO

-- dim_address — pooled address attributes across SLM property address and
-- the QUBE / FixFlo property records. No confirmed conformed key (e.g. UPRN)
-- across all three yet — grain here is "one address record per source", not
-- a deduplicated master.
CREATE OR ALTER VIEW gold.dim_address AS
SELECT
    CAST(HASHBYTES('SHA2_256', CONCAT_WS('|', 'SLM', a.property_hk)) AS BIGINT) AS address_key,
    'SLM'            AS source_system,
    a.property_hk,
    a.uprn,
    a.location       AS address_text
FROM silver.property_address AS a

UNION ALL

SELECT
    CAST(HASHBYTES('SHA2_256', CONCAT_WS('|', 'QUBE', q.property_hk)) AS BIGINT),
    'QUBE',
    q.property_hk,
    NULL,
    CONCAT_WS(', ', q.address1, q.address2, q.postcode)
FROM silver.property_qube AS q

UNION ALL

SELECT
    CAST(HASHBYTES('SHA2_256', CONCAT_WS('|', 'FixFlo', h.PropertyId)) AS BIGINT),
    'FixFlo',
    NULL,
    NULL,
    CONCAT_WS(', ', h.PropertyAddressLine1, h.PropertyAddressLine2, h.PropertyTown, h.PropertyPostCode)
FROM silver.property_fixflo_hierarchy AS h;
GO

-- dim_energy_rating — EPC-style attributes. Grain: one row per property
-- (current). If EPCs need to be tracked over time, add an effective-date
-- SCD2 pattern once refresh cadence is confirmed with the customer.
CREATE OR ALTER VIEW gold.dim_energy_rating AS
SELECT
    CAST(HASHBYTES('SHA2_256', e.property_hk) AS BIGINT) AS energy_rating_key,
    CAST(HASHBYTES('SHA2_256', e.property_hk) AS BIGINT) AS property_key,
    e.energy_rating_current,
    e.energy_rating_potential,
    e.environmental_impact_current,
    e.environmental_impact_potential
FROM silver.property_energy_rating AS e;
GO

-- ============================================================================
-- DOMAIN: PERSON / PARTY
-- ============================================================================

CREATE OR ALTER VIEW gold.dim_person AS
SELECT
    CAST(HASHBYTES('SHA2_256', person_hk) AS BIGINT) AS person_key,
    person_hk,
    source_person_id,
    person_name
FROM silver.person;
GO

-- Bridge: which people hold which role(s) against which property.
-- Same many-to-many bridge-table pattern used for person<->address on SVoC.
CREATE OR ALTER VIEW gold.bridge_property_person_role AS
SELECT
    CAST(HASHBYTES('SHA2_256', r.property_hk) AS BIGINT) AS property_key,
    CAST(HASHBYTES('SHA2_256', r.person_hk) AS BIGINT)   AS person_key,
    r.role_code,
    r.role_name
FROM silver.property_person_role AS r;
GO

CREATE OR ALTER VIEW gold.bridge_property_owner AS
SELECT
    CAST(HASHBYTES('SHA2_256', o.property_hk) AS BIGINT) AS property_key,
    o.person_id,
    o.owner_role_code,
    o.contract_id
FROM silver.property_owner AS o;
GO

-- ============================================================================
-- DOMAIN: LANDLORD
-- ============================================================================

CREATE OR ALTER VIEW gold.dim_landlord AS
SELECT
    CAST(HASHBYTES('SHA2_256', ISNULL(l.ExternalLandlordRef, l.LandlordEmailAddress)) AS BIGINT) AS landlord_key,
    l.ExternalLandlordRef,
    l.LandlordDisplayName,
    l.LandlordCompanyName,
    l.LandlordFirstName,
    l.LandlordSurname,
    l.LandlordEmailAddress,
    l.LandlordTel1,
    l.LandlordTown,
    l.LandlordPostCode,
    l.LandlordIsDeleted
FROM silver.landlord AS l;
GO

-- ============================================================================
-- DOMAIN: CONTRACTOR (provisional — see silver.contractor notes)
-- ============================================================================

CREATE OR ALTER VIEW gold.dim_contractor AS
SELECT
    CAST(HASHBYTES('SHA2_256',
        CONCAT_WS('|', ISNULL(contractor_id,''), ISNULL(contractor_company_name,''),
                        ISNULL(contractor_first_name,''), ISNULL(contractor_surname,''))
    ) AS BIGINT)                       AS contractor_key,
    contractor_id,
    contractor_company_name,
    contractor_first_name,
    contractor_surname
FROM silver.contractor;
GO

-- ============================================================================
-- DOMAIN: TENANT / OCCUPIER (provisional — see silver.occupier notes)
-- ============================================================================

CREATE OR ALTER VIEW gold.dim_tenant AS
SELECT
    CAST(HASHBYTES('SHA2_256', ISNULL(occupier_name,'')) AS BIGINT) AS tenant_key,
    occupier_name,
    occupier_email,
    occupier_phone,
    Occupier_Address_Line_1, Occupier_Address_Line_2, Occupier_town, Occupier_post_Code
FROM silver.occupier;
GO

-- ============================================================================
-- FACTS: REPAIRS / ISSUES  (includes the closest thing to an INVOICE domain
-- available today — see gold.fact_issue_cost below)
-- ============================================================================

CREATE OR ALTER VIEW gold.fact_issue AS
SELECT
    i.Issue_ID,
    -- CANDIDATE dimension links (unconfirmed keys, see workshop pack)
    CAST(HASHBYTES('SHA2_256', ISNULL(i.External_Unit_Ref,'')) AS BIGINT)                        AS property_key_candidate,
    CAST(HASHBYTES('SHA2_256', CONCAT_WS('|', ISNULL(i.Contractor_Id,''), ISNULL(i.Contractor_Company_Name,''),
                                                ISNULL(i.Contractor_Firstname,''), ISNULL(i.Contractor_Surname,''))) AS BIGINT) AS contractor_key,
    CAST(HASHBYTES('SHA2_256', ISNULL(i.Occupier_display_Name,'')) AS BIGINT)                     AS tenant_key,
    CONVERT(int, FORMAT(i.issue_created_date, 'yyyyMMdd'))                                        AS issue_created_date_key,
    CONVERT(int, FORMAT(i.closed_date, 'yyyyMMdd'))                                               AS closed_date_key,
    i.Fault_Category,
    i.Fault_Priority,
    i.Issue_Status,
    i.Close_Reason,
    i.days_to_close,
    i.price_agency_payable_gross,
    i.price_agency_receivable_gross,
    i.works_authorisation_limit
FROM silver.issue AS i;
GO

-- Thin "invoice / financial" proxy — no invoice source has been profiled in
-- either system yet (docx section 8 doesn't flag it, and no billing/ledger
-- table appears in the ERD). This exposes the closest existing cost data
-- (repair job payable/receivable amounts) under its own name so the customer
-- conversation about a real invoicing source has something concrete to react
-- to, not because it's a substitute for one.
CREATE OR ALTER VIEW gold.fact_issue_cost AS
SELECT
    Issue_ID,
    Fault_Category,
    Contractor_Id,
    Contractor_Company_Name,
    price_agency_payable_gross,
    price_agency_receivable_gross,
    works_authorisation_limit,
    issue_created_date,
    closed_date
FROM silver.issue
WHERE price_agency_payable_gross IS NOT NULL
   OR price_agency_receivable_gross IS NOT NULL;
GO

CREATE OR ALTER VIEW gold.fact_customer_feedback AS
SELECT
    f.issue_Id,
    CAST(HASHBYTES('SHA2_256', CONCAT_WS('|', ISNULL(f.Contractor_Id,''), ISNULL(f.Contractor_Name,''))) AS BIGINT) AS contractor_key,
    f.Occupier_Contractor_Rating,
    f.Repair_Rating,
    f.Repair_Acknowledged_Promptly,
    f.Customer_Accept_Complete
FROM silver.customer_feedback AS f;
GO

-- ============================================================================
-- FACTS: SERVICE / MAINTENANCE
-- ============================================================================

CREATE OR ALTER VIEW gold.fact_service_event AS
SELECT
    s.Reference_Id,
    CAST(HASHBYTES('SHA2_256', ISNULL(s.Fixflo_Unit_Property_ID,'')) AS BIGINT)                    AS property_key_candidate,
    CAST(HASHBYTES('SHA2_256', CONCAT_WS('|', '', ISNULL(s.Contractor_Company_Name,''),
                                                ISNULL(s.Contractor_Firstname,''), ISNULL(s.Contractor_Surname,''))) AS BIGINT) AS contractor_key,
    s.Latest_Issue_Id,
    CONVERT(int, FORMAT(s.due_date, 'yyyyMMdd'))         AS due_date_key,
    CONVERT(int, FORMAT(s.instruction_date, 'yyyyMMdd')) AS instruction_date_key,
    s.Service_Frequency,
    s.Frequency_Period,
    s.Service_Event_Status,
    s.Requires_Review
FROM silver.service_event AS s;
GO

CREATE OR ALTER VIEW gold.fact_last_completed_event AS
SELECT
    l.Service_Event_ID,
    CAST(HASHBYTES('SHA2_256', ISNULL(l.Unit_Property_ID,'')) AS BIGINT)                          AS property_key_candidate,
    CAST(HASHBYTES('SHA2_256', CONCAT_WS('|', l.Block_ID, l.Block_Ext_Ref)) AS BIGINT)             AS block_key,
    CAST(HASHBYTES('SHA2_256', CONCAT_WS('|', '', ISNULL(l.Contractor_Company_Name,''),
                                                ISNULL(l.Contractor_First_Name,''), ISNULL(l.Contractor_Surname,''))) AS BIGINT) AS contractor_key,
    CONVERT(int, FORMAT(l.last_completed_date, 'yyyyMMdd')) AS last_completed_date_key,
    l.Planned_Maintenance_Event_Frequency,
    l.Completed_Status,
    l.Planned_Maintenance_Event_Requires_Review
FROM silver.last_completed_event AS l;
GO

-- ============================================================================
-- FACTS: COMPLIANCE / CERTIFICATE
-- ============================================================================

CREATE OR ALTER VIEW gold.fact_completed_event_certificate AS
SELECT
    c.Service_Event_Reference_ID,
    c.Unit_Reference,
    CONVERT(int, FORMAT(c.due_date, 'yyyyMMdd'))         AS due_date_key,
    CONVERT(int, FORMAT(c.completed_date, 'yyyyMMdd'))   AS completed_date_key,
    CASE WHEN c.Certificate_Media_File IS NOT NULL THEN 1 ELSE 0 END AS has_certificate
FROM silver.completed_event_certificate AS c;
GO

-- ============================================================================
-- FACTS: COMPLAINTS
-- ============================================================================

CREATE OR ALTER VIEW gold.fact_tenant_complaint AS
SELECT
    t.Reference_Number,
    CAST(HASHBYTES('SHA2_256', ISNULL(t.Property_Ref,'')) AS BIGINT) AS property_key_candidate,
    CAST(HASHBYTES('SHA2_256', ISNULL(t.Tenant_Name,'')) AS BIGINT)  AS tenant_key,
    t.Complaint_Category,
    t.complaint_status,
    CONVERT(int, FORMAT(t.date_of_complaint, 'yyyyMMdd'))            AS date_of_complaint_key,
    CONVERT(int, FORMAT(t.complaint_acknowledged_on, 'yyyyMMdd'))    AS complaint_acknowledged_date_key
FROM silver.tenant_complaint AS t;
GO

-- ============================================================================
-- EXAMPLE JOINED-UP QUERY — property + repairs + certificates + energy
-- rating, to show the customer what "one view of a property" could surface.
-- Not a view, just a sample SELECT to demo in the workshop.
-- ============================================================================
/*
SELECT
    p.property_id,
    p.uprn,
    p.status,
    er.energy_rating_current,
    COUNT(DISTINCT i.Issue_ID)          AS open_issue_count,
    SUM(i.price_agency_payable_gross)   AS total_payable_gross,
    MAX(c.completed_date_key)           AS last_certificate_completed
FROM gold.dim_property AS p
LEFT JOIN gold.dim_energy_rating AS er
    ON er.property_key = p.property_key
LEFT JOIN gold.fact_issue AS i
    ON i.property_key_candidate = p.property_key
LEFT JOIN gold.fact_completed_event_certificate AS c
    ON 1 = 0 -- placeholder: no confirmed key from certificate back to property yet
GROUP BY p.property_id, p.uprn, p.status, er.energy_rating_current;
*/
